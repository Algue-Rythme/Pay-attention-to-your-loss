import tensorflow as tf
import os
import glob

try:
    import matplotlib.pyplot as plt
except ImportError:
    plt = None
try:
    import seaborn as sns
except ImportError:
    sns = None
try:
    import wandb
except ImportError:
    wandb = None


class WeightHist(tf.keras.callbacks.Callback):
    def __init__(self, use_wandb, **kwargs):
        super().__init__()
        self.use_wandb = use_wandb
        if not use_wandb:
            files = glob.glob("supervised_hists/*")
            for f in files:
                os.remove(f)

    def plot_with_wandb(self, epoch, names, weights):
        if wandb is None:
            raise ImportError(
                "WeightHist.plot_with_wandb() requires wandb. Please install wandb."
            )
        to_plot_weights = {}
        for name, weight in zip(names, weights):
            weight = weight.numpy()
            to_plot_weights[f"weights_{name}"] = wandb.Histogram(weight)
        wandb.log(
            to_plot_weights, commit=False
        )  # wandb callback ensures the commit later

    def plot_with_plt(self, epoch, names, weights):
        if plt is None:
            raise ImportError(
                "WeightHist.plot_with_plt() requires matplotlib. Please install "
                "matplotlib."
            )
        if sns is None:
            raise ImportError(
                "WeightHist.plot_with_plt() requires sns. Please install sns."
            )

        s = 3
        from math import ceil

        _, axes = plt.subplots(nrows=s, ncols=ceil(len(weights) / s), figsize=(24, 16))
        axes = [col for row in axes for col in row]
        for i, (name, weight) in enumerate(zip(names, weights)):
            weight = weight.numpy()
            axes[i].set_xlim(0.0, float(weight.max()) * 1.2)
            axes[i].set_xlabel(name)
            sns.histplot(data=weight.flatten(), bins=16, ax=axes[i])
        plt.savefig(f"supervised_hists/weight_{int(epoch+1)}.png")
        plt.close()

    def on_epoch_end(self, epoch, logs=None):
        names = [var.name for var in self.model.trainable_variables]
        weights = [weight for weight in self.model.trainable_variables]
        if self.use_wandb:
            self.plot_with_wandb(epoch, names, weights)
        else:
            self.plot_with_plt(epoch, names, weights)
