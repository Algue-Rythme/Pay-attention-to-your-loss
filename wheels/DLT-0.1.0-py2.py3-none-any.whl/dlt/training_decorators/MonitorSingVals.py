import tensorflow as tf
import numpy as np

try:
    import scipy
except ImportError:
    scipy = None
try:
    import wandb
except ImportError:
    wandb = None


class WeightHist(tf.keras.callbacks.Callback):
    def __init__(self, **kwargs):
        super().__init__()

    def plot_with_wandb(self, epoch, names, weights, sigmas):
        if scipy is None:
            raise ImportError(
                "WeightHist.plot_with_wandb() requires scipy. Please install scipy."
            )
        if wandb is None:
            raise ImportError(
                "WeightHist.plot_with_wandb() requires wandb. Please install wandb."
            )

        to_plot_weights = {}
        for name, weight in zip(names, weights):
            weight = weight.numpy()
            to_plot_weights[f"weights_{name}"] = wandb.Histogram(weight)
            if "kernel" in name:
                try:
                    weight = weight.reshape(
                        (-1, weight.shape[-1])
                    )  # ensure square matrix with rank 2
                    eigenvalues = scipy.linalg.svdvals(weight)  # biggest singular value
                    if "spectral" in name:
                        prefix = "/".join(
                            name.split("/")[:-1]
                        )  # whole layer name, drop Variable's name
                        sigma_name = prefix + "/sigma:0"
                        sigma = sigmas[sigma_name]  # retrieve the sigma associated
                        ratios = eigenvalues / sigma.numpy()
                        to_plot_weights[f"singular_ratio_{name}"] = wandb.Histogram(
                            ratios
                        )
                    else:
                        to_plot_weights[f"singular_{name}"] = wandb.Histogram(
                            eigenvalues
                        )
                except np.linalg.LinAlgError:
                    print("WARNING: np.eigvals did not converge")
        wandb.log(
            to_plot_weights, commit=False
        )  # wandb callback ensures the commit later

    def on_epoch_end(self, epoch, logs=None):
        names = [var.name for var in self.model.trainable_variables]
        weights = [weight for weight in self.model.trainable_variables]
        sigmas = {
            weight.name: weight
            for weight in self.model.non_trainable_variables
            if "sigma" in weight.name
        }
        self.plot_with_wandb(epoch, names, weights, sigmas)
