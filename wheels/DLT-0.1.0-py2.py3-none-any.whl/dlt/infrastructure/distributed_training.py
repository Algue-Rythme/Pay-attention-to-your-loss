import tensorflow as tf


def get_distribution_strategy():
    """
    Returns the distribution strategy based on the available hardware in the
    following order:
      1. TPU strategy if a TPU is detected
      2. GPU (multiple or single)
      3. CPU

    .. highlight:: python
    .. code-block:: python

        strategy = get_distribution_strategy()
        with strategy.scope():
            model = ...
            model.compile(...)

        model.fit(ds_train, batch_size=batch_size * strategy.num_replicas_in_sync)

    Returns:
        tf.distribute.Strategy: the best strategy depending on the available
        hardware
    """
    # shamelessly stolen from
    # https://colab.research.google.com/github/tensorflow/tpu/blob/master/tools/colab/keras_mnist_tpu.ipynb
    # /blob/master/tools/colab/keras_mnist_tpu.ipynb#scrollTo=Hd5zB1G7Y9-7
    # Detect hardware
    try:
        tpu_resolver = (
            tf.distribute.cluster_resolver.TPUClusterResolver()
        )  # TPU detection
    except ValueError:
        tpu_resolver = None
        gpus = tf.config.experimental.list_logical_devices("GPU")

    # Select appropriate distribution strategy
    if tpu_resolver:
        tf.config.experimental_connect_to_cluster(tpu_resolver)
        tf.tpu.experimental.initialize_tpu_system(tpu_resolver)
        strategy = tf.distribute.experimental.TPUStrategy(tpu_resolver)
        print("Running on TPU ", tpu_resolver.cluster_spec().as_dict()["worker"])
    elif len(gpus) > 1:
        strategy = tf.distribute.MirroredStrategy([gpu.name for gpu in gpus])
        print("Running on multiple GPUs ", [gpu.name for gpu in gpus])
    elif len(gpus) == 1:
        strategy = (
            tf.distribute.get_strategy()
        )  # default strategy that works on CPU and single GPU
        print("Running on single GPU ", gpus[0].name)
    else:
        strategy = (
            tf.distribute.get_strategy()
        )  # default strategy that works on CPU and single GPU
        print("Running on CPU")

    print("Number of accelerators: ", strategy.num_replicas_in_sync)
    return strategy


def with_accelerators(make_and_compile_model_fct):
    """
    Annotation that can be added to a function that builds and compiles a model.
    Once the annotation is added, the function builds the network with the appropriate
    strategy. The strategy object is also returned, so instead of returning the model,
    the function returns the model and the strategy.

    .. highlight:: python
    .. code-block:: python

        @with_accelerators
        def make_and_compile_model(**kwargs):
            ...
            return compiled_model

        model, strategy = make_and_compile_model(**kwargs)

    Args:
        make_and_compile_model_fct: a function that builds and compiles the model

    """
    def make_and_compile_with_accelerators(*make_fct_args, **make_fct_kwargs):

        strategy = get_distribution_strategy()
        with strategy.scope():
            model = make_and_compile_model_fct(*make_fct_args, **make_fct_kwargs)

        # print model layers
        model.summary()

        return model, strategy

    return make_and_compile_with_accelerators
