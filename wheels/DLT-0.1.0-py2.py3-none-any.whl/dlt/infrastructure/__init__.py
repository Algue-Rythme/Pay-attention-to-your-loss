"""
Infrastructure module contains utility functions to ease the building of models on
specific architecture like multi GPU or TPU. It aims to make code run on very
different hardware with minor modifications.
"""
from . import distributed_training
