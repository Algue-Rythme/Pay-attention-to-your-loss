import tensorflow as tf
from deel.lip.activations import GroupSort2
from deel.lip.layers import (
    ScaledGlobalL2NormPooling2D,
    SpectralConv2D,
    FrobeniusDense,
)
from tensorflow.keras import Input
from tensorflow.keras.layers import (
    Dense,
    Conv2D,
    DepthwiseConv2D,
    GlobalAveragePooling2D,
    Activation,
    Add,
    BatchNormalization,
)
from tensorflow.keras.activations import gelu
from tensorflow.keras.models import Model
from dlt.model_factory.utils import ClassParam
from dlt.extras.layers.skip_connections import LipAddSkip
from dlt.extras.layers.depwise_conv import SpectralDepthwiseConv2D

convmixer_1536_20 = dict(
    width=1536,
    depth=20,
    patch_size=7,
    kernel_size=9,
)

convmixer_768_32 = dict(
    width=768,
    depth=32,
    patch_size=7,
    kernel_size=7,
)

convmixer_256_8 = dict(
    width=256,
    depth=8,
    patch_size=2,
    kernel_size=5,
)

non_lip_layer_params = dict(
    conv=ClassParam(Conv2D, padding="valid", use_bias=True),
    dw_conv=ClassParam(DepthwiseConv2D, padding="same", use_bias=True),
    last_dense=ClassParam(Dense, activation=None, use_bias=False),
    global_pooling=ClassParam(GlobalAveragePooling2D),
    activation=ClassParam(Activation, gelu),
    skip_connection=Add,
    normalization=BatchNormalization,
)

lip_layer_params = dict(
    conv=ClassParam(SpectralConv2D, padding="same", use_bias=True),
    dw_conv=ClassParam(SpectralDepthwiseConv2D, padding="same", use_bias=True),
    last_dense=ClassParam(FrobeniusDense, activation=None, use_bias=False),
    global_pooling=ClassParam(ScaledGlobalL2NormPooling2D),
    activation=ClassParam(GroupSort2),
    skip_connection=LipAddSkip,
    normalization=None,
)


def ConvMixer(
    input_shape,
    nb_classes,
    h=256,
    depth=8,
    patch_size=2,
    kernel_size=5,
    conv: ClassParam = ClassParam(Conv2D, padding="valid", use_bias=True),
    dw_conv: ClassParam = ClassParam(DepthwiseConv2D, padding="same", use_bias=True),
    last_dense: ClassParam = ClassParam(Dense, activation=None, use_bias=False),
    global_pooling: ClassParam = ClassParam(GlobalAveragePooling2D),
    activation: ClassParam = ClassParam(Activation, gelu),
    skip_connection=Add,
    normalization=BatchNormalization,
    name=None,
):
    """
    Build a ConvMixer architecture.

    See Also:
        https://arxiv.org/abs/2201.09792

    Args:
        input_shape: input shape of the network, not including batch size.
        nb_classes: number of classes.
        h: the number of channels used internally, as describer in the paper.
        depth: the number of convmixer layers, as described in the paper.
        patch_size: the patch size, done with a convolution with stride (patch_size,
            patch_size)
        kernel_size: the kernel size used in depthwise convolution
        conv: ClassParam encapsulating the class used for convolutions and it's default
            args.
        dw_conv: ClassParam encapsulating the class used for depthwise convolutions
            and it's default args.
        last_dense: ClassParam encapsulating the class used for convolutions and it's
            default args. It s given separately to allow the use of custom
            activation, bias...
        global_pooling: ClassParam encapsulating the global pooling layer.
        activation: ClassParam encapsulating the activation layer.
        skip_connection: ClassParam encapsulating the skip connections. Skip
            connections are given as layers ( for instance tf.keras.layers.Add ). Can
            be set to None.
        normalization: Normalization layer (as BatchNorm, LayerNorm...)
            but can also be set to None.
        name: model's name

    Returns:
        a tf.keras.Model object

    """

    def conv_mixer_fct(x):
        x = conv(
            h,
            kernel_size=(patch_size, patch_size),
            strides=(patch_size, patch_size),
            padding="same",
        )(x)
        x = activation()(x)
        for i in range(depth):
            x1 = dw_conv(kernel_size=(kernel_size, kernel_size), padding="same")(x)
            x1 = activation()(x1)
            if normalization is not None:
                x1 = normalization()(x1)
            if skip_connection is not None:
                x1 = skip_connection()((x, x1))
            x1 = conv(h, kernel_size=(1, 1), padding="valid")(x1)
            x1 = activation()(x1)
            if normalization is not None:
                x = normalization()(x1)
            else:
                x = x1
        x = global_pooling()(x)
        out = last_dense(nb_classes)(x)
        return out

    inp = Input(shape=input_shape)
    out = conv_mixer_fct(inp)
    model = Model(inp, out, name=name)
    return model


if __name__ == "__main__":
    model = ConvMixer((32, 32, 3), 10, **convmixer_256_8)
    model.build((32, 32, 3))
    model(tf.random.uniform((2, 32, 32, 3)))
    model.summary()
