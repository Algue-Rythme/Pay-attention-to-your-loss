import tensorflow as tf
from deel.lip.activations import GroupSort2
from deel.lip.layers import SpectralDense, FrobeniusDense
from tensorflow.keras.activations import gelu
from tensorflow.keras.layers import (
    Dense,
    Input,
    LayerNormalization,
    GlobalAveragePooling1D,
    Activation,
    Add,
)
from tensorflow.keras.models import Model
from dlt.model_factory.utils import ClassParam
from dlt.extras.layers.skip_connections import LipAddSkip

mixer_S32 = dict(
    num_layers=8,
    patch_size=32,
    hidden_dim=512,
    DC=2048,
    DS=256,
)

mixer_S16 = dict(
    num_layers=8,
    patch_size=16,
    hidden_dim=512,
    DC=2048,
    DS=256,
)

mixer_B32 = dict(
    num_layers=12,
    patch_size=32,
    hidden_dim=768,
    DC=3072,
    DS=384,
)

mixer_B16 = dict(
    num_layers=12,
    patch_size=16,
    hidden_dim=768,
    DC=3072,
    DS=384,
)

mixer_L32 = dict(
    num_layers=24,
    patch_size=32,
    hidden_dim=1024,
    DC=4096,
    DS=512,
)

mixer_L16 = dict(
    num_layers=24,
    patch_size=16,
    hidden_dim=1024,
    DC=4096,
    DS=512,
)

mixer_H14 = dict(
    num_layers=32,
    patch_size=14,
    hidden_dim=1280,
    DC=5120,
    DS=640,
)

non_lip_layers_params = dict(
    dense=ClassParam(Dense, use_bias=True),
    last_dense=ClassParam(Dense, use_bias=True),
    global_pooling_1D=GlobalAveragePooling1D,
    activation=ClassParam(Activation, gelu),
    skip_connection=Add,
    normalization=LayerNormalization,
)

lip_layers_params = dict(
    dense=ClassParam(SpectralDense, use_bias=True),
    last_dense=ClassParam(FrobeniusDense, disjoint_neurons=True, use_bias=True),
    global_pooling_1D=GlobalAveragePooling1D,
    activation=ClassParam(GroupSort2),
    skip_connection=LipAddSkip,
    normalization=None,
)


def _MLPBlock(
    mlp_dim: int,
    dense: ClassParam,
    activation: ClassParam,
):
    def mlp_block_fct(x):
        x1 = activation()(x)
        x2 = dense(mlp_dim)(x1)
        x3 = activation()(x2)
        y = dense(x.shape.as_list()[-1])(x3)
        return y

    return mlp_block_fct


def _MixerBlock(
    DC: int,
    DS: int,
    dense: ClassParam,
    activation: ClassParam,
    skip_connection: ClassParam,
    normalization: ClassParam,
):
    def mixer_block_fct(x):
        if normalization is not None:
            x = normalization()(x)
        x2 = tf.transpose(x, [0, 2, 1])
        x3 = _MLPBlock(DS, dense, activation)(x2)
        x4 = tf.transpose(x3, [0, 2, 1])
        if skip_connection is not None:
            x4 = skip_connection()((x, x4))
        if normalization is not None:
            x4 = normalization()(x4)
        x5 = _MLPBlock(DC, dense, activation)(x4)
        if skip_connection is not None:
            x5 = skip_connection()((x5, x4))
        return x5

    return mixer_block_fct


def MLPMixer(
    input_shape,
    nb_classes,
    num_layers=12,
    patch_size=16,
    hidden_dim=768,
    DC=3072,
    DS=384,
    dense: ClassParam = ClassParam(Dense, use_bias=True),
    last_dense: ClassParam = ClassParam(Dense, use_bias=True),
    global_pooling_1D: ClassParam = GlobalAveragePooling1D,
    activation: ClassParam = ClassParam(Activation, gelu),
    skip_connection=Add,
    normalization=LayerNormalization,
    name="MLP_B16",
):
    """
    Build an MLP Mixer model.

    See Also:
        https://arxiv.org/pdf/2105.01601v4.pdf

    Args:
        input_shape: input shape of the network, not including batch size.
        nb_classes: number of classes.
        num_layers: number of MLP blocks, as defined in table 1 of the paper.
        patch_size: the patch size
        hidden_dim: the hidden dimension used inside between MLP blocks
        DC: channels dimensions Dc as defined in paper.
        DS: token dimensions Ds as defined in paper.
        dense: ClassParam encapsulating the class used for dense layers and it's
            default args.
        last_dense:  ClassParam encapsulating the class used for convolutions and it's
            default args. It s given separately to allow the use of custom
            activation, bias...
        global_pooling_1D: ClassParam encapsulating the class used for the last global
            pooling layer.
        activation: ClassParam encapsulating the activation layer.
        skip_connection: ClassParam encapsulating the skip connections. Skip
            connections are given as layers ( for instance tf.keras.layers.Add ). Can
            be set to None.
        normalization: Normalization layer (as BatchNorm, LayerNorm...)
            but can also be set to None.

    Returns:
        a tf.keras.Model object

    """

    def mlp_mixer_fct(x):
        x = tf.image.extract_patches(
            images=x,
            sizes=[1, patch_size, patch_size, 1],
            strides=[1, patch_size, patch_size, 1],
            rates=[1, 1, 1, 1],
            padding="VALID",
        )
        shape = x.shape.as_list()
        x = tf.keras.layers.Reshape((shape[1] * shape[2], shape[3]))(x)
        x = dense(hidden_dim)(x)
        for _ in range(num_layers):
            x = _MixerBlock(
                DC,
                DS,
                dense,
                activation,
                skip_connection,
                normalization,
            )(x)
        x = global_pooling_1D()(x)
        out = last_dense(nb_classes)(x)
        return out

    inp = Input(shape=input_shape)
    out = mlp_mixer_fct(inp)
    model = Model(inp, out, name=name)
    return model


if __name__ == "__main__":
    model_conf = mixer_L16
    model_conf.update(non_lip_layers_params)
    model = MLPMixer((224, 224, 3), 1000, **model_conf)
    model.build((224, 224, 3))
    model(tf.random.uniform((2, 224, 224, 3)))
    model.summary()
