from typing import Iterable
from deel.lip.layers import (
    ScaledL2NormPooling2D,
    SpectralConv2D,
    SpectralDense,
    FrobeniusDense,
    ScaledGlobalL2NormPooling2D,
)
from deel.lip.activations import GroupSort2
import tensorflow as tf
from tensorflow.keras.layers import (
    Input,
    Dense,
    Conv2D,
    ReLU,
    GlobalAveragePooling2D,
    BatchNormalization,
    Dropout,
    MaxPool2D,
    Add,
)
from deel.lip.model import Model
from dlt.model_factory.utils import ClassParam
from dlt.extras.layers.skip_connections import LipAddSkip

non_lip_layers_params = dict(
    conv=ClassParam(Conv2D, kernel_size=(3, 3), padding="same", use_bias=True),
    dense=ClassParam(Dense, use_bias=True),
    last_dense=ClassParam(Dense, activation=None, use_bias=True),
    pooling=MaxPool2D,
    global_pooling=ClassParam(
        GlobalAveragePooling2D,
    ),
    activation=ClassParam(ReLU),
    skip_connection=Add,
    normalization=BatchNormalization,
    dropout=ClassParam(Dropout, 0.1),
)

lip_layers_params = dict(
    conv=ClassParam(SpectralConv2D, kernel_size=(3, 3), padding="same", use_bias=True),
    dense=ClassParam(SpectralDense, use_bias=True),
    last_dense=ClassParam(
        FrobeniusDense, disjoint_neurons=True, activation=None, use_bias=True
    ),
    pooling=ScaledL2NormPooling2D,
    global_pooling=ClassParam(
        ScaledGlobalL2NormPooling2D,
    ),
    activation=ClassParam(GroupSort2),
    skip_connection=LipAddSkip,  # LipL2NormSkip
    normalization=None,  # ClassParam(BatchNormalization(center=True, scale=False,)),
    dropout=None,  # ClassParam(Dropout, 0.1),
)


def get_wrn_x_y_cifar_structure(depth, k):
    """
    Compute the param for given depth and k, as done in the paper. Note that
    nb_groups is set to 3 for cifar networks, but the imagenet one have a different
    number of groups.

    Args:
        depth: depth of the network as given in the original paper
        k: width of the network (same as the k in the WRN function)

    Returns:
        a dictionary with kwargs about network's structure for the WRN function.

    """
    n = (depth - 4) // (3 * 2)
    structure = dict(
        k=k,
        n=n,
        base_filter=16,
        nb_groups=3,
        dense_sizes=(),
        name="WRN-28-10",
    )
    return structure


def WRN(
    input_shape: tuple = (32, 32, 3),
    nb_classes: int = 10,
    k: int = 10,
    n: int = 4,
    base_filter: int = 16,
    nb_groups: int = 3,
    dense_sizes: Iterable = (),
    conv: ClassParam = ClassParam(
        Conv2D, kernel_size=(3, 3), padding="same", use_bias=True
    ),
    dense: ClassParam = ClassParam(Dense, use_bias=True),
    last_dense: ClassParam = ClassParam(Dense, activation=None, use_bias=True),
    pooling: ClassParam = MaxPool2D,
    global_pooling: ClassParam = ClassParam(
        GlobalAveragePooling2D,
    ),
    activation: ClassParam = ClassParam(ReLU),
    skip_connection: ClassParam = Add,
    normalization=BatchNormalization,
    dropout=ClassParam(Dropout, 0.2),
    name="WRN-28-10",
):
    """
    Build a WRN network.

    See Also:
        https://arxiv.org/abs/1605.07146v4
    Args:
        input_shape: input shape of the network, not including batch size.
        nb_classes: number of classes.
        k: widening factor (channel increase inside a residual block).
        n: depthening factor (number of conv in a residual block).
        base_filter: number of base filter at the beginning of the network.
        nb_groups: number of group, each group is separated by a drop in resolusion.
        dense_sizes: tuple giving the number of neurons in dense classification
            layers (not including the last layer, which has nb_classes neurons)
        conv: ClassParam encapsulating the class used for convolutions and it's default
            args.
        dense: ClassParam encapsulating the class used for dense and it's default
            args.
        last_dense: ClassParam encapsulating the class used for convolutions and it's
            default args. It s given separately to allow the use of custom
            activation, bias...
        pooling: ClassParam encapsulating the class used for pooling layer. If None
            striding is used instead.
        global_pooling: ClassParam encapsulating the global pooling layer.
        activation: ClassParam encapsulating the activation layer.
        skip_connection: ClassParam encapsulating the skip connections. Skip
            connections are given as layers ( for instance tf.keras.layers.Add ). Can
            be set to None.
        normalization: Normalization layer (as BatchNorm, LayerNorm...)
            but can also be set to None.
        dropout: Dropout layer.
        name: model's name

    Returns:
        a tf.keras.Model object

    """
    inp = Input(shape=input_shape)
    x = inp
    # stem
    x = conv(base_filter, kernel_size=(7, 7))(x)
    if normalization is not None:
        x = normalization()(x)
    x = activation()(x)
    for i in range(nb_groups):
        # if there is no pooling and we are at the end of a block, use striding
        # instead
        if pooling is not None:
            x = pooling()(x)
            strides = (1, 1)
        else:
            strides = (2, 2)
        for d in range(n):
            y = x
            # BN -> act -> conv
            if normalization is not None:
                y = normalization()(y)
            y = activation()(y)
            y = conv(int(base_filter * (2 ** i) * k), strides=strides)(y)
            if strides == (2, 2):
                x = y  # skip connection cannot be done ahead this layer
                strides = (1, 1)
            # dropout
            if dropout is not None:
                y = dropout()(y)
            # BN -> act -> conv
            if normalization is not None:
                y = normalization()(y)
            y = activation()(y)
            y = conv(base_filter * (2 ** i) * k)(y)
            # skip connection
            if skip_connection is not None:
                if x.shape[1:] == y.shape[1:]:
                    x = skip_connection()((x, y))
                else:
                    x = skip_connection()((conv(y.shape[-1], kernel_size=(1, 1))(x), y))
            else:
                x = y
    x = global_pooling()(x)
    # use one or more dense before final dense layer
    for dense_size in dense_sizes:
        if normalization is not None:
            x = normalization()(x)
        x = dense(dense_size)(x)
        x = activation()(x)
    # final classif layer
    preds = last_dense(nb_classes)(x)
    model = Model(inp, preds, name=name)
    return model


if __name__ == "__main__":
    model_conf = get_wrn_x_y_cifar_structure(28, 10)
    model_conf.update(non_lip_layers_params)
    model = WRN((32, 32, 3), 100, **model_conf)
    model.build((32, 32, 3))
    model(tf.random.uniform((2, 32, 32, 3)))
    model.summary()
    tf.keras.utils.plot_model(model, "model.png")
