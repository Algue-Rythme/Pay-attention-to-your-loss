from typing import Iterable

from deel.lip.layers import (
    ScaledL2NormPooling2D,
    SpectralConv2D,
    SpectralDense,
    FrobeniusDense,
)
from deel.lip.activations import GroupSort2
import tensorflow as tf
from tensorflow.keras.layers import Input, Dense, Conv2D, Flatten, MaxPool2D, ReLU
from deel.lip.model import Model

from dlt.model_factory.utils import ClassParam

vgg16_structure = dict(
    conv_sizes=(
        (64, 64),
        (128, 128),
        (256, 256, 256),
        (512, 512, 512),
        (512, 512, 512),
    ),
    dense_sizes=(4096, 4096),
    name="VGG16",
)

vgg_A_structure = dict(
    conv_sizes=(
        (64,),
        (128,),
        (256, 256),
        (512, 512),
        (512, 512),
    ),
    dense_sizes=(4096, 4096),
    name="VGG-A",
)

vgg_B_structure = dict(
    conv_sizes=(
        (64, 64),
        (128, 128),
        (256, 256),
        (512, 512),
        (512, 512),
    ),
    dense_sizes=(4096, 4096),
    name="VGG-B",
)

vgg_E_structure = dict(
    conv_sizes=(
        (64, 64),
        (128, 128),
        (256, 256, 256, 256),
        (512, 512, 512, 512),
        (512, 512, 512, 512),
    ),
    dense_sizes=(4096, 4096),
    name="VGG-E",
)

non_lip_layers_params = dict(
    conv=ClassParam(Conv2D, kernel_size=(3, 3), padding="same", use_bias=True),
    dense=ClassParam(Dense, use_bias=True),
    last_dense=ClassParam(Dense, use_bias=True),
    pooling=ClassParam(MaxPool2D, pool_size=(2, 2)),
    activation=ReLU,
)

lip_layers_params = dict(
    conv=ClassParam(SpectralConv2D, kernel_size=(3, 3), padding="same", use_bias=True),
    dense=ClassParam(SpectralDense, use_bias=True),
    last_dense=ClassParam(FrobeniusDense, disjoint_neurons=True, use_bias=False),
    pooling=ClassParam(ScaledL2NormPooling2D, pool_size=(2, 2)),
    activation=GroupSort2,
)


def VGG(
    input_shape: tuple = (224, 224, 3),
    nb_classes: int = 1000,
    conv_sizes: Iterable = (
        (64, 64),
        (128, 128),
        (256, 256, 256),
        (512, 512, 512),
        (512, 512, 512),
    ),
    dense_sizes: Iterable = (4096, 4096),
    conv: ClassParam = ClassParam(Conv2D, use_bias=True),
    dense: ClassParam = ClassParam(Dense, use_bias=True),
    last_dense: ClassParam = ClassParam(Dense, use_bias=False),
    pooling: ClassParam = ClassParam(MaxPool2D, pool_size=(2, 2)),
    global_pooling: ClassParam = ClassParam(
        Flatten,
    ),
    activation=ReLU,
    name="VGG16",
):
    """
    Build a VGG network.

    See Also:
        https://arxiv.org/pdf/1409.1556v6.pdf

    Args:
        input_shape: input shape of the network, not including batch size.
        nb_classes: number of classes.
        conv_sizes: list of tuple indicating the number of filter of each
            convolution. each tuple represent a block (separated by a pooling layer).
        dense_sizes: tuple giving the number of neurons in dense classification
            layers (not including the last layer, which has nb_classes neurons)
        conv: ClassParam encapsulating the class used for convolutions and it's default
            args.
        dense: ClassParam encapsulating the class used for dense and it's default
            args.
        last_dense: ClassParam encapsulating the class used for convolutions and it's
            default args. It s given separately to allow the use of custom
            activation, bias...
        pooling: ClassParam encapsulating the class used for pooling layer. If None
            striding is used instead.
        global_pooling: ClassParam encapsulating the global pooling layer.
        activation: ClassParam encapsulating the activation layer.
        name: model's name

    Returns:
        a tf.keras.Model object

    """
    inp = Input(shape=input_shape)
    x = inp
    for j, block_size in enumerate(conv_sizes):
        last_block = (j + 1) == len(conv_sizes)
        for i, filters in enumerate(block_size):
            last_conv = (i + 1) == len(block_size)
            strides = (
                (2, 2) if (pooling is None) and last_conv and not last_block else (1, 1)
            )
            x = conv(filters, strides=strides)(x)
            x = activation()(x)
        if (pooling is not None) and not last_block:
            x = pooling()(x)
    x = global_pooling()(x)
    for dense_size in dense_sizes:
        x = dense(dense_size)(x)
        x = activation()(x)
    preds = last_dense(nb_classes)(x)
    model = Model(inp, preds, name=name)
    return model


if __name__ == "__main__":
    model_conf = vgg16_structure
    model_conf.update(non_lip_layers_params)
    model = VGG((224, 224, 3), 1000, **model_conf)
    model.build((224, 224, 3))
    model(tf.random.uniform((2, 224, 224, 3)))
    model.summary()
