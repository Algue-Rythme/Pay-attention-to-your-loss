"""
The model factory contains functions to build some common architectures as VGG,
Resnets, wide resnets, mlpmixer convmixer...

All submodules are organized as following;
each file contains a factory function, with the following parameters:

- input shape
- number of classes
- structure/architecture hparams (width, depth...)
- class params (provide a flexible way to change type of layers for instance
  enabling/disabling skip connection, changing between BatchNorm and LayerNorm...)

Each file also contains dictionaries for default architectures:

- dictionaries for structure/architecture hparams
- dictionaries for class params (default set of layers for unconstrained networks
  for instance)

These dictionaries can be merged and used as kwargs for the factory.
"""
from . import convmixer
from . import mlpmixer
from . import utils
from . import vgg
from . import wrn
