import tensorflow as tf


def stiefel_manifold(grad, var_orig, beta):
    is_spectral = "dense" in var_orig.name  # or ('spectral_conv2d' in var.name)
    if not is_spectral or ("kernel" not in var_orig.name):
        return grad, var_orig
    # print("Stiefel on ", var_orig.name)
    flat_shape = (-1, tf.shape(grad)[-1])
    grad = tf.reshape(grad, flat_shape)
    var = tf.reshape(var_orig, flat_shape)
    assert len(grad.shape) == 2
    ogo = tf.linalg.matmul(var, grad, transpose_b=True) @ var
    if var.shape[0] == var.shape[1]:
        return (1 - beta) * grad - beta * ogo, var_orig
    if var.shape[0] > var.shape[1]:
        proj_og = tf.linalg.matmul(var, var, transpose_b=True)
        proj_og = proj_og @ var
    else:
        proj_og = tf.linalg.matmul(var, var, transpose_a=True)
        proj_og = var @ proj_og
    grad = grad - beta * (ogo + proj_og)  # final projection
    grad = tf.reshape(grad, tf.shape(var_orig))
    return grad, var_orig


def preprocess_grads(gradients, trainable_vars):
    return [stiefel_manifold(grad, var) for grad, var in zip(gradients, trainable_vars)]


def stiefel_grad_transformer(grad_n_vars):
    """
    l2_normalize the gradient of each kernel.
    """
    out_grads_n_vars = []
    for grad, var in grad_n_vars:
        out_grads_n_vars.append(stiefel_manifold(grad, var, 0.25))
    return out_grads_n_vars
