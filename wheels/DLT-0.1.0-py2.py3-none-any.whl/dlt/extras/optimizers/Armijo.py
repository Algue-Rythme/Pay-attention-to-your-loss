import tensorflow as tf


class Armijo:
    def __init__(self, batch_size, train_size):
        self.opt = tf.keras.optimizers.SGD(learning_rate=1.0)
        self.c = 0.1
        self.beta = 0.6
        self.gamma = 2 ** (batch_size / train_size)
        self.eta = 1.0
        self.max_eta = 1.0
        self.min_eta = 2e-6

    def update_model(self, model):
        self.model = model
        # custom_objects = CUSTOM_OBJECTS
        # custom_objects['MultiLipschitzHead'] = MultiLipschitzHead
        # self.clone = self.model.__class__.from_config(self.model.get_config(), custom_objects)

    def c_grad_norm(self, gradients):
        return self.c * tf.linalg.global_norm(gradients) ** 2.0

    @staticmethod
    def wolfe_condition(target, source, norm, eta):
        return tf.less_equal(target, source + eta * norm)

    @staticmethod
    def rescale(factor, grads):
        return map(lambda grad: factor * grad, grads)

    def update_lr(self, source, x, labels, gradients):
        norm = self.c_grad_norm(gradients)
        old_weights = self.model.get_weights()
        # self.clone.set_weights(weights)
        trainable_vars = self.model.trainable_variables
        eta = self.eta * self.gamma
        self.opt.apply_gradients(zip(Armijo.rescale(eta, gradients), trainable_vars))
        target = self.model.compiled_loss(labels, self.model(x, training=True))
        while not Armijo.wolfe_condition(target, source, norm, eta):
            if eta < self.min_eta:
                break
            eta *= self.beta
            new_step = Armijo.rescale(eta * (1 - 1 / self.beta), gradients)
            self.opt.apply_gradients(zip(new_step, trainable_vars))
            target = self.model.compiled_loss(labels, self.model(x, training=True))
        self.model.set_weights(old_weights)
        self.eta = min(self.max_eta, eta)

    def __call__(self):
        return self.eta
