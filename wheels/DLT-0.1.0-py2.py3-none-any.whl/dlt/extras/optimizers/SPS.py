import tensorflow as tf
from tensorflow.keras.optimizers import SGD
from tensorflow.keras.utils import register_keras_serializable

@register_keras_serializable("dlt", "StochasticPolyakStepSizeClass")
class StochasticPolyakStepSizeClass(SGD):
    def __init__(self, fstar=0, c=0.5, eps=1e-7, eta_max=None, *args, **kwargs):
        self.fstar = fstar
        self.c = c
        self.eps = eps
        self.eta_max = eta_max if eta_max is not None else tf.float32.max
        super().__init__(
            learning_rate=1,
            momentum=0.0,
            nesterov=False,
            *args,
            **kwargs
        )

    def grad_transformer(self, grads_and_vars, loss):
        grads, var = zip(*grads_and_vars)
        grad_norm = compute_grad_norm(grads)
        step_size = tf.cond(
            tf.less_equal(grad_norm, 1e-8),
            lambda: 0.0,
            lambda: (loss - self.fstar) / (self.c * (grad_norm ** 2) + self.eps),
        )
        step_size = tf.cond(
            tf.less_equal(loss, self.fstar), lambda: 0.0, lambda: step_size
        )
        step_size = tf.math.minimum(self.eta_max, step_size)
        grads = [g * step_size for g in grads]
        return zip(grads, var)

    def _compute_gradients(self, loss, var_list, grad_loss=None, tape=None):
        grads_and_vars = super()._compute_gradients(loss, var_list, grad_loss, tape)
        grads_and_vars = self.grad_transformer(grads_and_vars, loss)
        return grads_and_vars

    def get_config(self):
        config = {
            "fstar": self.fstar,
            "c": self.c,
            "eps": self.eps,
            "eta_max": self.eta_max,
        }
        # base_config = super(StochasticPolyakStepSizeClass, self).get_config()
        return config  # dict(list(base_config.items()) + list(config.items()))


def compute_grad_norm(grad_list):
    grad_norm = 0.0
    for g in grad_list:
        grad_norm += tf.reduce_sum(tf.multiply(g, g))
    grad_norm = tf.sqrt(grad_norm)
    return grad_norm
