import tensorflow as tf
from deel.lip.normalizers import reshaped_kernel_orthogonalization


def l2_norm(grad_n_vars):
    """
    l2_normalize the gradient of each kernel.
    """
    out_grads_n_vars = []
    for grad, var in grad_n_vars:
        if "kernel" in var.name:
            out_grads_n_vars.append(
                (
                    tf.linalg.l2_normalize(grad),
                    var,
                )
            )
        else:
            out_grads_n_vars.append((grad, var))
    return out_grads_n_vars


def orthogonal(grad_n_vars):
    """
    l2_normalize the gradient of each kernel.
    """
    out_grads_n_vars = []
    for grad, var in grad_n_vars:
        if "kernel" in var.name:
            out_grads_n_vars.append(
                (
                    reshaped_kernel_orthogonalization(grad, None, 1.0),
                    var,
                )
            )
        else:
            out_grads_n_vars.append((grad, var))
    return out_grads_n_vars


def sign(grad_n_vars):
    """
    Apply sign function on each gradient. (kernel and biases)
    """
    out_grads_n_vars = []
    for grad, var in grad_n_vars:
        out_grads_n_vars.append(
            (
                tf.sign(
                    grad  # / tf.sqrt(tf.reduce_prod(tf.cast(grad.shape, grad.dtype)))
                ),
                var,
            )
        )
    return out_grads_n_vars


class RoundRobinGT:
    def __init__(self) -> None:
        """
        This gradient transformer zeroes out gradients for each layer except one.
        The updated layer changes at each call in a round robin fashion.
        """
        self.i = 0

    def __call__(self, grad_n_vars):
        out_grads_n_vars = []
        for i, (grad, var) in enumerate(grad_n_vars):
            if i == self.i:
                out_grads_n_vars.append(
                    (
                        grad,
                        var,
                    )
                )
            else:
                out_grads_n_vars.append(
                    (
                        tf.zeros_like(grad),
                        var,
                    )
                )
        self.i = (self.i + 1) % len(grad_n_vars)
        return out_grads_n_vars


class SigmaClippingGT:
    def __init__(self, sigma=2.0) -> None:
        """
        Clips the gradient betwwen [mu - sigma**stddev, mu + sigma**stddev]
        where mu is the mean value for each layer and sigma is the stdev
        """
        assert sigma > 0.0
        self.sigma = sigma

    def __call__(self, grad_n_vars):
        """
        l2_normalize the gradient of each kernel.
        """
        out_grads_n_vars = []
        for grad, var in grad_n_vars:
            grad_mean = tf.reduce_mean(grad)
            grad_std = tf.sqrt(tf.reduce_mean(tf.square(grad - grad_mean)))
            out_grads_n_vars.append(
                (
                    tf.clip_by_value(
                        grad,
                        grad_mean - self.sigma * grad_std,
                        grad_mean + self.sigma * grad_std,
                    ),
                    var,
                )
            )
        return out_grads_n_vars


class DepthDecayGT:
    def __init__(self, decay) -> None:
        self.decay = decay

    def __call__(self, grad_n_vars):
        out_grads_n_vars = []
        len_weights = len(grad_n_vars)
        for i, (grad, var) in enumerate(grad_n_vars):
            out_grads_n_vars.append(
                (
                    grad * self.decay ** (len_weights - i),
                    var,
                )
            )
        return out_grads_n_vars


class LinearDepthDecayGT:
    def __init__(self, decay_first, decay_last) -> None:
        self.decay_first = decay_first
        self.decay_last = decay_last

    def __call__(self, grad_n_vars):
        out_grads_n_vars = []
        len_weights = len(grad_n_vars)
        for i, (grad, var) in enumerate(grad_n_vars):
            out_grads_n_vars.append(
                (
                    grad
                    * (
                        self.decay_first
                        + i * (self.decay_last - self.decay_first) / len_weights
                    ),
                    var,
                )
            )
        return out_grads_n_vars
