# import tensorflow as tf
# from tensorflow.keras import layers


# def cayley_func(W):
#     _, cout, cin = W.shape
#     if cin > cout:
#         return cayley_func(W.transpose(1, 2)).transpose(1, 2)
#     U, V = W[:, :cin], W[:, cin:]
#     I = torch.eye(cin, dtype=W.dtype, device=W.device)[None, :, :]
#     A = U - U.conj().transpose(1, 2) + V.conj().transpose(1, 2) @ V
#     iIpA = torch.inverse(I + A)
#     return torch.cat((iIpA @ (I - A), -2 * V @ iIpA), axis=1)


# class Cayley(layers.Conv2D):
#     def __init__(self, *args, **kwargs):
#         super().__init__(*args, **kwargs)
#         n = 32
#         cout, cin, _, _ = self.weight.shape
#         s = (self.weight.shape[2] - 1) // 2
#         curr_shift_matrix = (
#             self.fft_shift_matrix(n, -s)[:, : (n // 2 + 1)]
#             .reshape(n * (n // 2 + 1), 1, 1)
#             .to(self.weight.device)
#         )

#         wfft = (
#             curr_shift_matrix
#             * torch.fft.rfft2(self.weight, (n, n))
#             .reshape(cout, cin, n * (n // 2 + 1))
#             .permute(2, 0, 1)
#             .conj()
#         )
#         self.alpha = nn.Parameter(
#             torch.tensor(wfft.norm().item(), requires_grad=True).to(self.weight.device)
#         )

#     def fft_shift_matrix(self, n, s):
#         shift = torch.arange(0, n).repeat((n, 1))
#         shift = shift + shift.T
#         return torch.exp(1j * 2 * np.pi * s * shift / n)

#     def forward(self, x):
#         # cout, cin, _, _ = self.weight.shape
#         _, _, cin, cout = self.weight.shape
#         # batches, _, n, _ = x.shape
#         batches, n, _, _ = x.shape
#         # todo: put in build
#         # if not hasattr(self, 'shift_matrix'):
#         #     s = (self.weight.shape[2] - 1) // 2
#         #     self.shift_matrix = self.fft_shift_matrix(n, -s)[:, :(n//2 + 1)].reshape(n * (n // 2 + 1), 1, 1).to(x.device)

#         xfft = tf.signal.fft2d(
#             x
#         )  # .fft.rfft2(x, s=x.shape[2:]).permute(2, 3, 1, 0).reshape(n * (n // 2 + 1), cin, batches)
#         wfft = (
#             self.shift_matrix
#             * torch.fft.rfft2(self.weight, (n, n))
#             .reshape(cout, cin, n * (n // 2 + 1))
#             .permute(2, 0, 1)
#             .conj()
#         )
#         if self.alpha is None:
#             self.alpha = nn.Parameter(
#                 torch.tensor(wfft.norm().item(), requires_grad=True).to(x.device)
#             )
#         yfft = (cayley_func(self.alpha * wfft / wfft.norm()) @ xfft).reshape(
#             n, n // 2 + 1, cout, batches
#         )

#         y = torch.fft.irfft2(yfft.permute(3, 2, 0, 1), x.shape[2:])
#         if self.bias is not None:
#             y += self.bias[:, None, None]
#         return y
