import tensorflow as tf
from tensorflow.keras import initializers
from tensorflow.keras.initializers import Initializer, Orthogonal, RandomNormal
from tensorflow.keras.layers import Conv2D, Layer
import tensorflow.keras.backend as K
from tensorflow.keras.utils import register_keras_serializable
from deel.lip.layers import LipschitzLayer, Condensable


@register_keras_serializable("dlt", "OrthoConvInitializer")
class OrthoConvInitializer(Initializer):
    def __init__(
        self,
        input_shape,
        niter=20,
        base_initializer=Orthogonal(gain=1.0, seed=None),
    ) -> None:
        self.niter = niter
        self.input_shape = input_shape
        self.base_initializer = initializers.get(base_initializer)
        super(OrthoConvInitializer, self).__init__()

    def __call__(self, shape, dtype=None, partition_info=None):
        w = self.base_initializer(shape=shape, dtype=dtype)
        norm = get_OperatorNorm(w, self.input_shape)
        W_bar = w / norm
        W_bar = Clip_OperatorNorm(W_bar, self.input_shape, self.niter, 1)
        norm = get_OperatorNorm(W_bar, self.input_shape)
        W_bar = W_bar / norm
        return W_bar

    def get_config(self):
        return {
            "input_shape": self.input_shape,
            "niter": self.niter,
            "base_initializer": initializers.serialize(self.base_initializer),
        }


@register_keras_serializable("dlt", "OrthoConv2D")
class OrthoConv2D(Conv2D, LipschitzLayer, Condensable):
    def __init__(
        self,
        filters,
        kernel_size,
        strides=(1, 1),
        padding="valid",
        data_format=None,
        dilation_rate=(1, 1),
        activation=None,
        use_bias=True,
        kernel_initializer="orthogonal",
        bias_initializer="zeros",
        kernel_regularizer=None,
        bias_regularizer=None,
        activity_regularizer=None,
        kernel_constraint=None,
        bias_constraint=None,
        k_coef_lip=1.0,
        niter=5,
        beta=1,
        **kwargs
    ):
        """
        This class is a Conv2D Layer constrained such that all singular of it's kernel
        are 1. The computation based on BjorckNormalizer algorithm. As this is not
        enough to ensure 1 Lipschitzity a coertive coefficient is applied on the
        output.
        The computation is done in three steps:

        1. reduce the largest singular value to 1, using iterated power method.
        2. increase other singular values to 1, using BjorckNormalizer algorithm.
        3. divide the output by the Lipschitz bound to ensure k Lipschitzity.

        Args:
            filters: Integer, the dimensionality of the output space
                (i.e. the number of output filters in the convolution).
            kernel_size: An integer or tuple/list of 2 integers, specifying the
                height and width of the 2D convolution window.
                Can be a single integer to specify the same value for
                all spatial dimensions.
            strides: An integer or tuple/list of 2 integers,
                specifying the strides of the convolution along the height and width.
                Can be a single integer to specify the same value for
                all spatial dimensions.
                Specifying any stride value != 1 is incompatible with specifying
                any `dilation_rate` value != 1.
            padding: one of `"valid"` or `"same"` (case-insensitive).
            data_format: A string,
                one of `channels_last` (default) or `channels_first`.
                The ordering of the dimensions in the inputs.
                `channels_last` corresponds to inputs with shape
                `(batch, height, width, channels)` while `channels_first`
                corresponds to inputs with shape
                `(batch, channels, height, width)`.
                It defaults to the `image_data_format` value found in your
                Keras config file at `~/.keras/keras.json`.
                If you never set it, then it will be "channels_last".
            dilation_rate: an integer or tuple/list of 2 integers, specifying
                the dilation rate to use for dilated convolution.
                Can be a single integer to specify the same value for
                all spatial dimensions.
                Currently, specifying any `dilation_rate` value != 1 is
                incompatible with specifying any stride value != 1.
            activation: Activation function to use.
                If you don't specify anything, no activation is applied
                (ie. "linear" activation: `a(x) = x`).
            use_bias: Boolean, whether the layer uses a bias vector.
            kernel_initializer: Initializer for the `kernel` weights matrix.
            bias_initializer: Initializer for the bias vector.
            kernel_regularizer: Regularizer function applied to
                the `kernel` weights matrix.
            bias_regularizer: Regularizer function applied to the bias vector.
            activity_regularizer: Regularizer function applied to
                the output of the layer (its "activation")..
            kernel_constraint: Constraint function applied to the kernel matrix.
            bias_constraint: Constraint function applied to the bias vector.
            k_coef_lip: lipschitz constant to ensure
            niter_spectral: number of iteration to find the maximum singular value.
            niter_bjorck: number of iteration with BjorckNormalizer algorithm.

        This documentation reuse the body of the original keras.layers.Conv2D doc.
        """
        if not (
            (dilation_rate == (1, 1))
            or (dilation_rate == [1, 1])
            or (dilation_rate == 1)
        ):
            raise RuntimeError("NormalizedConv does not support dilation rate")
        super(OrthoConv2D, self).__init__(
            filters=filters,
            kernel_size=kernel_size,
            strides=strides,
            padding=padding,
            data_format=data_format,
            dilation_rate=dilation_rate,
            activation=activation,
            use_bias=use_bias,
            kernel_initializer=kernel_initializer,
            bias_initializer=bias_initializer,
            kernel_regularizer=kernel_regularizer,
            bias_regularizer=bias_regularizer,
            activity_regularizer=activity_regularizer,
            kernel_constraint=kernel_constraint,
            bias_constraint=bias_constraint,
            **kwargs
        )
        self._kwargs = kwargs
        self.set_klip_factor(k_coef_lip)
        self.niter = niter
        self.beta = beta

    def build(self, input_shape):
        super(OrthoConv2D, self).build(input_shape)
        self._init_lip_coef(input_shape)
        self.u = self.add_weight(
            shape=tuple([1, self.kernel.shape.as_list()[-1]]),
            initializer=RandomNormal(0, 1),
            name="sn",
            trainable=False,
            dtype=self.dtype,
        )

        # self.sig = self.add_weight(
        #     shape=(1),  # maximum spectral  value
        #     name="sigma",
        #     trainable=False,
        #     dtype=self.dtype,
        # )
        # self.sig.assign((1.0, ))
        self.built = True

    def _compute_lip_coef(self, input_shape=None):
        return 1

    def call(self, x, training=None):
        # if training:
        # W_bar = self.kernel
        shape = self._build_input_shape[1:]
        shape0 = min(
            shape[0] - (self.kernel.shape[0] - 1), self.kernel.shape[0] * 2 + 1
        )
        shape1 = min(
            shape[1] - (self.kernel.shape[1] - 1), self.kernel.shape[1] * 2 + 1
        )
        if self.niter != 0:
            # norm = get_OperatorNorm(self.kernel, (shape0, shape1, shape[-1]))
            # W_bar = self.kernel / (norm+1e-7)
            W_bar = Clip_OperatorNorm(
                self.kernel, (shape0, shape1, shape[-1]), self.niter, self.beta
            )
            shape0 = shape[0] - (self.kernel.shape[0] - 1)
            shape1 = shape[1] - (self.kernel.shape[1] - 1)
            norm = get_OperatorNorm(W_bar, (shape0, shape1, shape[-1]))
            W_bar = W_bar / (norm + 1e-7)
        else:
            norm = get_OperatorNorm(self.kernel, (shape0, shape1, shape[-1]))
            W_bar = self.kernel / (norm + 1e-7)

            # self.W_bar = W_bar
            # self.sig.assign((norm, ))
        # else:
        #     W_bar = self.kernel # / self.sig
        outputs = K.conv2d(
            x,
            W_bar,
            strides=self.strides,
            padding=self.padding,
            data_format=self.data_format,
            dilation_rate=self.dilation_rate,
        )
        if self.use_bias:
            outputs = K.bias_add(outputs, self.bias, data_format=self.data_format)
        if self.activation is not None:
            return self.activation(outputs)
        return outputs

    def get_config(self):
        config = {
            "k_coef_lip": self.k_coef_lip,
            "niter": self.niter,
            "beta": self.beta,
        }
        base_config = super(OrthoConv2D, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))

    def condense(self):
        shape = self._build_input_shape[1:]
        shape0 = min(
            shape[0] - (self.kernel.shape[0] - 1), self.kernel.shape[0] * 2 + 1
        )
        shape1 = min(
            shape[1] - (self.kernel.shape[1] - 1), self.kernel.shape[1] * 2 + 1
        )
        # norm = get_OperatorNorm(self.kernel, (shape0, shape1, shape[-1]))
        # W_bar = self.kernel / (norm+1e-7)
        W_bar = Clip_OperatorNorm(
            self.kernel, (shape0, shape1, shape[-1]), self.niter, self.beta
        )
        shape0 = shape[0] - (self.kernel.shape[0] - 1)
        shape1 = shape[1] - (self.kernel.shape[1] - 1)
        norm = get_OperatorNorm(W_bar, (shape0, shape1, shape[-1]))
        W_bar = W_bar / (norm + 1e-7)
        # norm = get_OperatorNorm(self.kernel, (shape0, shape1, shape[-1]))
        # W_bar = self.kernel / (norm+1e-7)
        self.kernel.assign(W_bar)

    def vanilla_export(self):
        self._kwargs["name"] = self.name
        layer = Conv2D(
            filters=self.filters,
            kernel_size=self.kernel_size,
            strides=self.strides,
            padding=self.padding,
            data_format=self.data_format,
            dilation_rate=self.dilation_rate,
            activation=self.activation,
            use_bias=self.use_bias,
            kernel_initializer="glorot_uniform",
            bias_initializer="zeros",
            **self._kwargs
        )
        layer.build(self.input_shape)
        layer.kernel.assign(self.kernel.numpy() * self._get_coef())
        if self.use_bias:
            layer.bias.assign(self.bias.numpy())
        return layer


@tf.function
def padding_circular(x, cPad):
    if cPad is None:
        return x
    w_pad, h_pad = cPad
    if w_pad > 0:
        x = tf.concat((x[:, -w_pad:, :, :], x, x[:, :w_pad, :, :]), axis=1)
    if h_pad > 0:
        x = tf.concat((x[:, :, -h_pad:, :], x, x[:, :, :h_pad, :]), axis=2)
    return x


@register_keras_serializable("dlt", "CircularPadding")
class CircularPadding(Layer, LipschitzLayer):
    def __init__(self, padding_size=(0, 0), data_format=None, **kwargs):
        """
        CircularPadding operation for 3D data. to be compatible with fft implementation.

        Arguments:
            data_format: A string,
                one of `channels_last` (default) or `channels_first`.
                The ordering of the dimensions in the inputs.
                `channels_last` corresponds to inputs with shape
                `(batch, spatial_dim1, spatial_dim2, spatial_dim3, channels)`
                while `channels_first` corresponds to inputs with shape
                `(batch, channels, spatial_dim1, spatial_dim2, spatial_dim3)`.
                It defaults to the `image_data_format` value found in your
                Keras config file at `~/.keras/keras.json`.
                If you never set it, then it will be "channels_last".
                        padding_size: a tuple (height_padding, width_padding)
        Input shape:
            - If `data_format='channels_last'`:
                5D tensor with shape:
                `(batch_size, spatial_dim1, spatial_dim2, spatial_dim3, channels)`
            - If `data_format='channels_first'`:
                5D tensor with shape:
                `(batch_size, channels, spatial_dim1, spatial_dim2, spatial_dim3)`

        Output shape:
            2D tensor with shape `(batch_size, spatial_dim1+2*height_padding,spatial_dim2+2*width_padding, channels)`.
        """
        if len(padding_size) != 2:
            raise RuntimeError("Padding tupple should contain 2 values ")
        if data_format != None and data_format != "channels_last":
            raise RuntimeError("CircularPadding in  channels_last mode only")
        self.padding_size = padding_size
        self._kwargs = kwargs
        super(CircularPadding, self).__init__()

    def build(self, input_shape):
        super(CircularPadding, self).build(input_shape)
        self._init_lip_coef(input_shape)
        self.built = True

    def _compute_lip_coef(self, input_shape=None):
        return 1.0

    @tf.function
    def call(self, x, training=None):
        """if self.padding_size[0]!=0:
            x=tf.concat((x[:,-self.padding_size[0]:,:,:],x,x[:,:self.padding_size[0],:,:]),axis=1)
        if self.padding_size[1]!=0:
            x=tf.concat((x[:,:,-self.padding_size[1]:,:],x,x[:,:,:self.padding_size[1],:]),axis=2)"""
        return padding_circular(x, self.padding_size)

    def get_config(self):
        config = {"padding_size": self.padding_size}
        base_config = super(CircularPadding, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


@tf.function
def Clip_OperatorNorm(conv, inp_shape, niter, beta):
    """

    Args:
        conv:
        inp_shape:
        beta: if beta is 1 we project tatally

    Returns:

    """
    # reshape to image size before fft
    # conv = tf.clip_by_value(conv, clip_value_min=-1, clip_value_max=1)
    conv_tr = tf.cast(tf.transpose(conv, perm=[2, 3, 0, 1]), tf.complex64)
    conv_shape = conv.get_shape().as_list()
    padding = tf.constant(
        [
            [0, 0],
            [0, 0],
            [0, inp_shape[0] - conv_shape[0]],
            [0, inp_shape[1] - conv_shape[1]],
        ]
    )
    # crop_mask = tf.pad(tf.ones_like(conv_tr), padding, constant_values=(1-beta))
    crop_mask = tf.pad(
        tf.ones_like(conv_tr, dtype=tf.float32), padding, constant_values=(1 - beta)
    )
    conv_tr_padded = tf.pad(conv_tr, padding)
    # with tf.device("GPU:0"):
    for i in range(niter):
        # apply FFT
        transform_coeff = tf.signal.fft2d(conv_tr_padded)
        # tf.print(tf.linalg.norm(tf.math.real(transform_coeff)), tf.linalg.norm(tf.math.imag(transform_coeff)))
        # q, r = tf.linalg.qr(tf.transpose(transform_coeff, perm = [2, 3, 0, 1]), full_matrices=True)
        # # Make Q uniform
        # d = tf.linalg.diag_part(r)
        # q *= tf.sign(d)
        # clipped_coeff = q

        D, U, V = tf.linalg.svd(tf.transpose(transform_coeff, perm=[2, 3, 0, 1]))
        # norm = tf.reduce_max(D)

        # perform pseudo orthogonalization
        D_clipped = tf.cast(beta * tf.ones_like(D) + (1 - beta) * D, tf.complex64)
        # reconstruct kernel in fft domain
        clipped_coeff = tf.matmul(
            U, tf.matmul(tf.linalg.diag(D_clipped), V, adjoint_b=True)
        )
        # clipped_coeff = tf.matmul(U, tf.linalg.adjoint(V))
        # perform inverse fft
        clipped_conv_padded = tf.signal.ifft2d(
            tf.transpose(clipped_coeff, perm=[2, 3, 0, 1])
        )
        # pseudo crop
        conv_tr_padded = tf.cast(
            tf.multiply(tf.math.real(clipped_conv_padded), crop_mask), tf.complex64
        )
    constrained_conv = tf.slice(
        tf.transpose(tf.math.real(conv_tr_padded), perm=[2, 3, 0, 1]),
        [0] * len(conv_shape),
        conv_shape,
    )
    # tf.print(tf.linalg.norm(constrained_conv), tf.reduce_mean(tf.math.abs(constrained_conv)))
    # return tf.clip_by_value(constrained_conv, clip_value_min=-1, clip_value_max=1)
    return constrained_conv


@tf.function
def get_OperatorNorm(conv, inp_shape):
    """

    Args:
        conv:
        inp_shape:
        beta: if beta is 1 we project tatally

    Returns:

    """
    conv_tr = tf.cast(tf.transpose(conv, perm=[2, 3, 0, 1]), tf.complex64)
    conv_shape = conv.get_shape().as_list()
    padding = tf.constant(
        [
            [0, 0],
            [0, 0],
            [0, inp_shape[0] - conv_shape[0]],
            [0, inp_shape[1] - conv_shape[1]],
        ]
    )
    conv_tr_padded = tf.pad(conv_tr, padding)
    # apply FFT
    transform_coeff = tf.math.real(tf.signal.fft2d(conv_tr_padded))
    D, U, V = tf.linalg.svd(tf.transpose(transform_coeff, perm=[2, 3, 0, 1]))
    # D = tf.linalg.eigvals(tf.transpose(transform_coeff, perm = [2, 3, 0, 1]))
    norm = tf.reduce_max(D)
    return norm
