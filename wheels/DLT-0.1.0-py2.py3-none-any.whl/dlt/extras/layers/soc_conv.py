import abc

import numpy as np
import tensorflow as tf
from tensorflow.keras import backend as K
from tensorflow.keras.initializers import RandomNormal
import tensorflow.keras.layers as keraslayers

from deel.lip.constraints import SpectralConstraint
from deel.lip.initializers import SpectralInitializer
from deel.lip.normalizers import (
    DEFAULT_EPS_BJORCK,
    DEFAULT_EPS_SPECTRAL,
    reshaped_kernel_orthogonalization,
    spectral_normalization_conv,
    DEFAULT_BETA_BJORCK,
)
from deel.lip.layers import (
    LipschitzLayer,
    Condensable,
    InvertibleDownSampling,
    SpectralConv2D,
)
from tensorflow.keras.utils import register_keras_serializable
from math import pi


@register_keras_serializable("dlt", "SOCConv2D")
class SOCConv2D(keraslayers.Conv2D, LipschitzLayer, Condensable):
    """
    Same as SpectralConv2D but in the case of a single output.
    """

    def __init__(
        self,
        filters,
        kernel_size,
        strides=(1, 1),
        padding="same",
        data_format=None,
        dilation_rate=(1, 1),
        activation=None,
        use_bias=True,
        kernel_initializer=SpectralInitializer(),
        bias_initializer="zeros",
        kernel_regularizer=None,
        bias_regularizer=None,
        activity_regularizer=None,
        kernel_constraint=None,
        bias_constraint=None,
        k_coef_lip=1.0,
        **kwargs,
    ):
        if not (
            (dilation_rate == (1, 1))
            or (dilation_rate == [1, 1])
            or (dilation_rate == 1)
        ):
            raise RuntimeError("NormalizedConv does not support dilation rate")
        if padding != "same":
            raise RuntimeError("NormalizedConv only support padding='same'")
        super(SOCConv2D, self).__init__(
            filters=filters,
            kernel_size=kernel_size,
            strides=strides,
            padding=padding,
            data_format=data_format,
            dilation_rate=dilation_rate,
            activation=activation,
            use_bias=use_bias,
            kernel_initializer=kernel_initializer,
            bias_initializer=bias_initializer,
            kernel_regularizer=kernel_regularizer,
            bias_regularizer=bias_regularizer,
            activity_regularizer=activity_regularizer,
            kernel_constraint=kernel_constraint,
            bias_constraint=bias_constraint,
            **kwargs,
        )
        self.set_klip_factor(k_coef_lip)
        self._kwargs = kwargs

    def build(self, input_shape):
        if self.use_bias:
            self.bias = self.add_weight(
                name="bias",
                shape=(self.filters,),
                initializer=self.bias_initializer,
                regularizer=self.bias_regularizer,
                constraint=self.bias_constraint,
                trainable=True,
                dtype=self.dtype,
            )
        else:
            self.bias = None

        self._init_lip_coef(input_shape)
        (bs, w, h, cin) = input_shape
        c = max(cin * self.strides[0] * self.strides[1], self.filters)
        self.m = self.add_weight(
            "m",
            shape=(
                self.kernel_size[0] // self.strides[0],
                self.kernel_size[1] // self.strides[1],
                c,
                c,
            ),
            dtype=self.dtype,
            initializer=self.kernel_initializer,
            regularizer=self.kernel_regularizer,
            constraint=self.kernel_constraint,
            trainable=True,
        )
        # self.u = self.add_weight(
        #     "u",
        #     shape=(1, w // self.strides[0], h // self.strides[1], c, c),
        #     # dtype=self.dtype,
        #     trainable=False,
        #     initializer="ones",
        # )
        self.built = True

    def _compute_lip_coef(self, input_shape=None):
        k1 = self.kernel_size[0]
        k1_div2 = (k1 - 1) / 2
        k2 = self.kernel_size[1]
        k2_div2 = (k2 - 1) / 2
        if self.data_format == "channels_last":
            h = input_shape[-3]
            w = input_shape[-2]
        elif self.data_format == "channels_first":
            h = input_shape[-2]
            w = input_shape[-1]
        else:
            raise RuntimeError("data_format not understood: " % self.data_format)
        return np.sqrt(
            (w * h)
            / ((k1 * h - k1_div2 * (k1_div2 + 1)) * (k2 * w - k2_div2 * (k2_div2 + 1)))
        )

    @tf.function
    def call(self, x, training=True):
        k = 12
        if not (
            (self.strides == (1, 1)) or (self.strides == [1, 1]) or (self.strides == 1)
        ):
            x = InvertibleDownSampling(self.strides)(x)
        (bs, w, h, cin) = x.shape
        if cin < self.filters:
            x = tf.pad(
                x,
                paddings=[[0, 0], [0, 0], [0, 0], [0, self.filters - cin]],
                mode="CONSTANT",
                constant_values=0,
            )
        l = self.m - tf.transpose(self.m, perm=(1, 0, 2, 3))
        # l, u, sigma = spectral_normalization_conv(l, self.u)
        l, u, sigma = reshaped_kernel_orthogonalization(
            l, u=None, adjustment_coef=1.0, eps_bjorck=None, beta=None
        )
        l = l * self._get_coef()
        # self.u.assign(u)
        y = x
        factorial = 1
        for j in range(2, k):
            x = K.conv2d(x, l, padding="same")
            factorial = factorial * (j - 1)
            y = y + (x / factorial)
        if cin > self.filters:
            y = y[:, :, :, 0 : self.filters]
        outputs = y
        if self.use_bias:
            outputs = K.bias_add(outputs, self.bias, data_format=self.data_format)
        if self.activation is not None:
            return self.activation(outputs)
        return outputs

    def get_config(self):
        config = {
            "k_coef_lip": self.k_coef_lip,
        }
        base_config = super(SOCConv2D, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))

    def condense(self):
        pass

    def vanilla_export(self):
        raise RuntimeError("vanilla_export not implemented")
        # self._kwargs["name"] = self.name
        # # call the condense function from SpectralDense as if it was from this class
        # return SpectralConv2D.vanilla_export(self)


@register_keras_serializable("dlt", "HouseHolder")
class HouseHolder(keraslayers.Layer, LipschitzLayer):
    def __init__(
        self,
        data_format="channels_last",
        k_coef_lip=1.0,
        theta_initializer="zeros",
        *args,
        **kwargs,
    ):
        """
        GroupSort activation

        Args:
            data_format: either channels_first or channels_last
            k_coef_lip: the lipschitz coefficient to be enforced
            *args: params passed to Layers
            **kwargs: params passed to layers (named fashion)

        Input shape:
            Arbitrary. Use the keyword argument `input_shape` (tuple of integers, does
            not include the samples axis) when using this layer as the first layer in a
            model.

        Output shape:
            Same size as input.

        """
        self.set_klip_factor(k_coef_lip)
        self.theta_initializer = theta_initializer
        super(HouseHolder, self).__init__(*args, **kwargs)
        if data_format == "channels_last":
            self.channel_axis = -1
        elif data_format == "channels_first":
            self.channel_axis = 1
            raise RuntimeError(
                "channels_first not implemented for GroupSort activation"
            )
        else:
            raise RuntimeError("data format not understood")
        self.data_format = data_format

    def build(self, input_shape):
        super(HouseHolder, self).build(input_shape)
        self._init_lip_coef(input_shape)
        if (input_shape[self.channel_axis] % 2) != 0:
            raise RuntimeError("2 has to be a divisor of the number of channels")
        input_shape = tuple(input_shape.as_list())
        self.flat_shape = (-1,) + input_shape[1:-1] + (input_shape[-1] // 2, 2)
        self.out_shape = (-1,) + input_shape[1:]
        self.theta = self.add_weight(
            "theta",
            shape=(self.flat_shape[-2],),
            initializer=self.theta_initializer,
        )
        self.theta.assign(tf.ones_like(self.theta) * pi)
        if len(input_shape) == 4:
            self.einsum_hint = "ijk,bwhij->bwhij"
        elif len(input_shape) == 3:
            self.einsum_hint = "ijk,bhij->bhij"
        elif len(input_shape) == 2:
            self.einsum_hint = "ijk,bij->bij"
        else:
            raise RuntimeError(
                f"HouseHolder does not support input in dimension {len(input_shape)}"
            )

    def _compute_lip_coef(self, input_shape=None):
        return 1.0

    @tf.function
    def call(self, x, **kwargs):
        z = tf.reshape(x, self.flat_shape)
        z1, z2 = tf.split(z, 2, -1)
        cos_theta = tf.math.cos(self.theta)
        sin_theta = tf.math.sin(self.theta)
        cos_theta_2 = tf.math.cos(self.theta / 2)
        sin_theta_2 = tf.math.sin(self.theta / 2)
        hh_cond = tf.expand_dims(
            tf.squeeze(z1, axis=-1) * sin_theta_2
            - tf.squeeze(z1, axis=-1) * cos_theta_2,
            -1,
        )
        hh_transform = tf.reshape(
            tf.stack([cos_theta, sin_theta, sin_theta, -cos_theta], axis=-1),
            (self.flat_shape[-2], 2, 2),
        )
        hhz = tf.einsum(self.einsum_hint, hh_transform, z)
        sigma_z = tf.where(hh_cond > 0, hhz, z)
        sigma_z_reshaped = tf.reshape(sigma_z, tf.shape(x))
        return sigma_z_reshaped * self._get_coef()

    def get_config(self):
        config = {
            "k_coef_lip": self.k_coef_lip,
            "data_format": self.data_format,
            "theta_initializer": self.theta_initializer,
        }
        base_config = super(HouseHolder, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))

    def compute_output_shape(self, input_shape):
        return input_shape
