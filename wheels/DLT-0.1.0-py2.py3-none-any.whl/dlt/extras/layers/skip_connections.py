import tensorflow as tf
from tensorflow.keras.utils import register_keras_serializable
from tensorflow.keras.layers import Layer


@register_keras_serializable("dlt", "LipAddSkip")
class LipAddSkip(Layer):
    def __init__(self, alpha=0.5, **kwargs):
        """
        Additive skip connect with lipschitz correction factor.

        output = alpha * x1 + (1 - alpha) * x2

        Args:
            alpha: factor to weight the skip connection
            **kwargs: kwarg of layer base class
        """
        super().__init__(**kwargs)
        if alpha < 0 or alpha > 1.0:
            raise RuntimeError("alpha must be in [0, 1]")
        self.alpha = alpha

    @tf.function
    def call(self, inputs, **kwargs):
        if not isinstance(inputs, (list, tuple)):
            raise ValueError(
                "A skip layer should be called on a list of inputs. "
                f"Received: inputs={inputs} (not a list of tensors)"
            )
        return self.alpha * inputs[0] + (1 - self.alpha) * inputs[1]

    def get_config(self):
        config = {
            "alpha": self.alpha,
        }
        base_config = super().get_config()
        return dict(list(base_config.items()) + list(config.items()))


@register_keras_serializable("dlt", "LipL2NormSkip")
class LipL2NormSkip(Layer):
    """
    L2 norm pooling remastered as skip connection.

    output = sqrt((x1**2 + x2**2)/2)

    Args:
        alpha: factor to weight the skip connection
        **kwargs: kwarg of layer base class
    """

    def __init__(self, epsilon=1e-5, **kwargs):
        super().__init__(**kwargs)
        if epsilon < 0:
            raise RuntimeError("epsilon cannot be negative")
        self.epsilon = epsilon

    @tf.function
    def call(self, inputs, **kwargs):
        if not isinstance(inputs, (list, tuple)):
            raise ValueError(
                "A skip layer should be called on a list of inputs. "
                f"Received: inputs={inputs} (not a list of tensors)"
            )
        return tf.sqrt(tf.maximum((inputs[0] ** 2 + inputs[1] ** 2) / 2, self.epsilon))

    def get_config(self):
        config = {
            "epsilon": self.epsilon,
        }
        base_config = super().get_config()
        return dict(list(base_config.items()) + list(config.items()))


@register_keras_serializable("dlt", "LipMaxSkip")
class LipMaxSkip(Layer):
    """
    A skip connection based derived from MaxPooling:

    output = max(x, f(x))

    Warnings:
        This layer can lead to dead skip connections when there is a strong negative
        bias in the skipped block.

    Args:
        **kwargs: kwarg of layer base class
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    @tf.function
    def call(self, inputs, **kwargs):
        if not isinstance(inputs, (list, tuple)):
            raise ValueError(
                "A skip layer should be called on a list of inputs. "
                f"Received: inputs={inputs} (not a list of tensors)"
            )
        return tf.maximum(inputs[0], inputs[1])

    def get_config(self):
        config = {}
        base_config = super().get_config()
        return dict(list(base_config.items()) + list(config.items()))
