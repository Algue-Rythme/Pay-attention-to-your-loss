import tensorflow as tf


class TopKMarginHKR(tf.keras.losses.Loss):
    def __init__(self, alpha, margins, top_k):
        super().__init__(name="multitopkhkr")
        self.depth = len(margins)
        self.margins = tf.Variable(
            initial_value=tf.expand_dims(margins, axis=0),
            trainable=False,
        )
        self.indices = tf.expand_dims(tf.range(self.depth, dtype=tf.int64), axis=0)
        self.alpha = alpha
        self.top_k = top_k

    def call(self, y_true, y_pred):
        y_true = tf.cast(tf.reshape(y_true, [-1]), dtype=tf.int64)
        mask = tf.one_hot(y_true, depth=self.depth, dtype=tf.float32)
        signs = 2 * mask - 1
        y = signs * y_pred

        # wasserstein
        weights = mask * (self.depth - 2) + 1.0
        wass = -y * weights
        wass = tf.reduce_mean(wass, axis=1)

        # hinge
        y_pred_false = y_pred - mask * tf.reduce_max(y_pred, axis=1, keepdims=True)
        max_others, _ = tf.math.top_k(y_pred_false, k=self.top_k, sorted=False)
        y_pred_true = tf.reduce_sum(y_pred * mask, axis=1, keepdims=True)
        margin_other = y_pred_true - max_others
        true_margin = tf.reduce_sum(self.margins * mask, axis=1, keepdims=True)
        hinge = tf.nn.relu(true_margin - margin_other)
        hinge = tf.reduce_mean(hinge, axis=1)

        # combination
        losses = hinge + (1.0 / self.alpha) * wass

        # average over the batch
        loss = tf.reduce_mean(losses)
        return loss
