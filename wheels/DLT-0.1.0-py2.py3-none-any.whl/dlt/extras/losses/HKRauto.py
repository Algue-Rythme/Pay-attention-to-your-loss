import tensorflow as tf
import tensorflow.keras.backend as K
from tensorflow.keras.utils import register_keras_serializable
import sys
import numpy as np
from deel.lip.losses import MulticlassKR

try:
    import tensorflow_probability as tfp
except ImportError:
    tfp = None


@register_keras_serializable("dlt", "MulticlassHKRauto")
class MulticlassHKRauto(tf.keras.losses.Loss):
    def __init__(
        self,
        nb_class,
        alpha=None,
        perc=5,
        free=False,
        reduction=tf.keras.losses.Reduction.AUTO,
        name="MulticlassHKRauto",
    ):
        """
        Multi-class HKR loss with automatic setting of the Hinge margin and the
        regularization parameter alpha.

        The margins (one per class) are automatically computed based on the percentile
        of elements per class inside the margin. For example, with perc=5, the margin is
        updated in order to have 5% of the class inputs inside the margin:

            new_margin <- (1-lr)*old_margin + lr*computed_margin

        Args:
            nb_class (int): number of output classes.
            alpha (float): regularization parameter if not automatically set. Defaults
                to None for an automatic setting.
            perc (float): percentage of elements inside the margin.
            free (bool): different Hinge loss computation.
            reduction: type of reduction to apply to loss.
            name (str): optional name for the instance.
        """
        if tfp is None:
            raise ImportError(
                "HKR_multiclass_auto requires tensorflow_probability. Please install "
                "tensorflow_probability."
            )
        self.nb_class = nb_class
        self.alpha = alpha
        self.perc = perc
        self.free = free

        if self.alpha is None:
            self.alpha = 100.0 / perc
        self.MIN_MARGIN = 0.02
        self.margins = K.variable(
            np.array([self.MIN_MARGIN] * nb_class), dtype=tf.float32
        )
        self.learning_rate = 0.002
        self.KRloss = MulticlassKR(reduction=reduction, name=name)
        super().__init__(reduction=reduction, name=name)

    @tf.function
    def call(self, y_true, y_pred):
        # Compute y_true value and max of "not y_true" values
        vYtrue = tf.reduce_sum(y_pred * y_true, axis=-1)  ## keep only y_true value
        H1 = tf.where(
            y_true == 1, tf.reduce_min(y_pred), y_pred
        )  ## set y_true at minimum on batch to avoid being the max
        maxOthers = tf.reduce_max(H1, axis=-1)  # keep only not y_true max value

        # Estimate margins
        for i in range(y_true.shape[-1]):
            ind_true = tf.equal(y_true[:, i], 1)  # indices for elements of class i
            res = tf.boolean_mask(y_pred[:, i], ind_true) - tf.boolean_mask(
                maxOthers, ind_true
            )
            if (
                tf.size(res) >= 3
            ):  # update margin only if at least 3 elements in class i
                emp_perc = tfp.stats.percentile(res, self.perc)
                th_perc = K.std(res) * 1.414213 * tf.math.erfinv(
                    2 * self.perc / 100 - 1
                ) + K.mean(res)
                min_margin = tf.math.maximum(
                    self.MIN_MARGIN,
                    (1 - self.learning_rate) * self.margins[i]
                    + self.learning_rate
                    * (0.7 * emp_perc + 0.3 * tf.math.minimum(emp_perc, th_perc)),
                )
                self.margins[i].assign(min_margin)

        vMargin = tf.reduce_sum(self.margins * y_true, axis=-1)

        # computing elementwise margin term : margin + y_pred[i]-y_pred[target_class]
        if self.free:
            hinge = tf.nn.relu(vMargin - vYtrue + maxOthers)
        else:
            hinge = tf.nn.relu(vMargin / 2 - vYtrue) + tf.nn.relu(
                vMargin / 2 + maxOthers
            )

        loss_val = self.alpha * hinge - self.KRloss(y_true, y_pred)
        return tf.where(tf.math.is_nan(loss_val), tf.zeros_like(loss_val), loss_val)

    def get_config(self):
        config = {
            "nb_class": self.nb_class,
            "alpha": self.alpha,
            "perc": self.perc,
            "free": self.free,
        }
        base_config = super().get_config()
        return dict(list(base_config.items()) + list(config.items()))
