# Copyright IRT Antoine de Saint Exupéry et Université Paul Sabatier Toulouse III - All
# rights reserved. DEEL is a research program operated by IVADO, IRT Saint Exupéry,
# CRIAQ and ANITI - https://www.deel.ai/
# =====================================================================================
import tensorflow as tf
from tensorflow.keras.losses import Loss, cosine_similarity
from tensorflow.keras.losses import Reduction
from tensorflow.keras.utils import register_keras_serializable


@register_keras_serializable("deel-lip", "MulticlassRobustLoss")
class MulticlassRobustLoss(Loss):
    def __init__(
        self,
        alpha=1.0,
        min_margin=1.0,
        reduction=Reduction.AUTO,
        softmax_temp=None,
        name="MulticlassRobustLoss",
    ):
        self.alpha = tf.Variable(alpha, dtype=tf.float32)
        self.min_margin = tf.Variable(min_margin, dtype=tf.float32)
        self.softmax_temp = (
            tf.Variable(softmax_temp, dtype=tf.float32)
            if softmax_temp is not None
            else None
        )
        super(MulticlassRobustLoss, self).__init__(reduction, name)

    def call(self, y_true, y_pred):
        # y_pred = tf.convert_to_tensor(y_pred)
        # y_true = tf.cast(y_true, y_pred.dtype)
        # pos = tf.reduce_sum(y_true * y_pred, axis=-1)
        # neg = tf.reduce_max((1.0 - y_true) * y_pred, axis=-1)
        # zero = tf.cast(0.0, y_pred.dtype)
        # return tf.maximum(neg - pos + self.min_margin, zero) + self.alpha * (neg - pos)
        eps = 1e-3
        # values, classes = tf.math.top_k(y_pred, k=2)
        ynl_shape = (-1, tf.shape(y_pred)[-1] - 1)
        yl = tf.expand_dims(tf.boolean_mask(y_pred, y_true > eps), axis=-1)
        ynl = tf.reshape(
            tf.boolean_mask(y_pred, y_true <= eps),
            ynl_shape,
        )
        if self.softmax_temp is not None:
            weights = tf.math.softmax(self.softmax_temp * ynl, axis=-1)
            delta = tf.reduce_sum((yl - ynl) * weights, axis=-1)
        else:
            delta = yl - tf.reduce_max(ynl, axis=-1)
        return tf.nn.relu(-delta + self.min_margin) - delta / self.alpha
        # return -delta

    def get_config(self):
        config = {
            "alpha": self.alpha.numpy(),
            "min_margin": self.min_margin.numpy(),
            "softmax_temp": None
            if self.softmax_temp is None
            else self.softmax_temp.numpy(),
        }
        base_config = super(MulticlassRobustLoss, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


@register_keras_serializable("deel-lip", "RegularizedCosineLoss")
class RegularizedCosineLoss(Loss):
    def __init__(
        self,
        alpha=1.0,
        min_margin=36 / 255,
        reduction=Reduction.AUTO,
        name="RegularizedCosineLoss",
    ):
        self.alpha = tf.Variable(alpha)
        self.min_margin = tf.Variable(min_margin)
        super(RegularizedCosineLoss, self).__init__(reduction, name)

    def call(self, y_true, y_pred):
        # values, classes = tf.math.top_k(y_pred, k=2)
        ynl_shape = (-1, tf.shape(y_pred)[-1] - 1)
        yl = tf.boolean_mask(y_pred, y_true > 0)
        ynl = tf.reshape(
            tf.boolean_mask(y_pred, y_true <= 0),
            ynl_shape,
        )
        delta = yl - tf.reduce_max(ynl, axis=-1)
        # delta = tf.reduce_mean(
        #     tf.repeat(tf.expand_dims(yl, axis=-1), repeats=ynl_shape[-1], axis=-1)
        #     - tf.nn.softmax(ynl, axis=-1),
        #     axis=-1,
        # )
        cossim = cosine_similarity(y_true, y_pred)
        return cossim - self.alpha * delta  # * tf.nn.relu(-delta + self.min_margin)

    def get_config(self):
        config = {
            "alpha": self.alpha.numpy(),
            "min_margin": self.min_margin.numpy(),
        }
        base_config = super(RegularizedCosineLoss, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


@register_keras_serializable("deel-lip", "RegularizedCosineLoss2")
class RegularizedCosineLoss2(Loss):
    def __init__(
        self,
        alpha=1.0,
        reduction=Reduction.AUTO,
        name="RegularizedCosineLoss2",
    ):
        self.alpha = tf.Variable(alpha)
        super(RegularizedCosineLoss2, self).__init__(reduction, name)

    def call(self, y_true, y_pred):
        # values, classes = tf.math.top_k(y_pred, k=2)
        ynl_shape = (-1, tf.shape(y_pred)[-1] - 1)
        yl = tf.boolean_mask(y_pred, y_true > 0)
        ynl = tf.reshape(
            tf.boolean_mask(y_pred, y_true <= 0),
            ynl_shape,
        )
        delta = tf.multiply(
            tf.nn.softmax(ynl, axis=-1), tf.expand_dims(yl, axis=-1) - ynl
        )
        return cosine_similarity(y_true, y_pred) - self.alpha * tf.reduce_mean(
            tf.nn.relu(delta)
        )

    def get_config(self):
        config = {
            "alpha": self.alpha.numpy(),
        }
        base_config = super(RegularizedCosineLoss2, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


def delta(y_true, y_pred):
    ynl_shape = (-1, tf.shape(y_pred)[-1] - 1)
    yl = tf.boolean_mask(y_pred, y_true > 0)
    ynl = tf.reshape(
        tf.boolean_mask(y_pred, y_true <= 0),
        ynl_shape,
    )
    delta = yl - tf.reduce_max(ynl, axis=-1)
    return delta


class CallableLoss:
    def __init__(self, callable):
        self.callable = callable

    def __call__(self, y_true, y_pred):
        return self.callable(y_true, y_pred)

    def __add__(self, other):
        def call_delta(y_true, y_pred):
            return self(y_true, y_pred) + other(y_true, y_pred)

        def call_numeric(y_true, y_pred):
            return self(y_true, y_pred) + other

        if isinstance(other, (int, float)):
            return CallableLoss(call_numeric)
        else:
            return CallableLoss(call_delta)

    def __radd__(self, other):
        return self.__add__(other)

    def __sub__(self, other):
        def call_delta(y_true, y_pred):
            return self(y_true, y_pred) - other(y_true, y_pred)

        def call_numeric(y_true, y_pred):
            return self(y_true, y_pred) - other

        if isinstance(other, (int, float)):
            return CallableLoss(call_numeric)
        else:
            return CallableLoss(call_delta)

    def __mul__(self, other):
        def call_delta(y_true, y_pred):
            return self(y_true, y_pred) * other(y_true, y_pred)

        def call_numeric(y_true, y_pred):
            return other * self(y_true, y_pred)

        if isinstance(other, (int, float)):
            return CallableLoss(call_numeric)
        else:
            return CallableLoss(call_delta)

    def __rmul__(self, other):
        return self.__mul__(other)

    def __neg__(self):
        def call(y_true, y_pred):
            return -self(y_true, y_pred)

        return CallableLoss(call)

    def __abs__(self):
        def call(y_true, y_pred):
            return tf.abs(self(y_true, y_pred))

        return CallableLoss(call)

    def __geq__(self, other):
        def call_delta(y_true, y_pred):
            return tf.nn.relu(other(y_true, y_pred) - self(y_true, y_pred))

        def call_numeric(y_true, y_pred):
            return tf.nn.relu(other - self(y_true, y_pred))

        if isinstance(other, (int, float)):
            return CallableLoss(call_numeric)
        else:
            return CallableLoss(call_delta)

    def __gt__(self, other):
        return self.__geq__(other)

    def __leq__(self, other):
        def call_delta(y_true, y_pred):
            return tf.nn.relu(self(y_true, y_pred) - other(y_true, y_pred))

        def call_numeric(y_true, y_pred):
            return tf.nn.relu(self(y_true, y_pred) - other)

        if isinstance(other, (int, float)):
            return CallableLoss(call_numeric)
        else:
            return CallableLoss(call_delta)

    def __lt__(self, other):
        return self.__leq__(other)


Delta = CallableLoss(delta)

if __name__ == "__main__":
    yp = tf.convert_to_tensor([[0.5, 0.25, 0.1], [0.5, 0.25, 0.1], [0.5, 0.25, 0.1]])
    yt = tf.convert_to_tensor([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]])
    Loss = MulticlassRobustLoss(alpha=0, min_margin=0.3)
    l = Loss.call(yt, yp)
    print(l)
