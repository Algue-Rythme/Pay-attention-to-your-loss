from tensorflow.keras.utils import register_keras_serializable
import tensorflow as tf


@register_keras_serializable("dlt", "MysteryLoss")
class MysteryLoss:
    """
    This loss tries to maximize margins (difference between true logit and
    the others logits).

    loss = hinge(y_l - top_1) + gamma*hinge(y_l - top_2) + gamma**2*hinge(y_l -
    top_3) ...

    where y_l is the logit associated to the target class.

    hinge is adapted to maximize the margins and have positive margins:

    This weight a curve such that:
    if margin < min_margin: slope of -1
    if margin > min_margin: slope of -alpha

    """

    def __init__(self, alpha, min_margin=0.01, k=10, discount_factor=0.5):
        self.alpha = alpha
        self.min_margin = min_margin
        self.discount_factor = discount_factor
        self.k = k
        self.__name__ = "MysteryLoss"
        self.gammas = tf.Variable([discount_factor ** i for i in range(k)])

    @tf.function
    def __call__(self, y_true, y_pred):
        # take the positive logit value for each sample.
        # example:
        # y_pred = [[0.2, 0.5], [-0.1, 0.1]] where y_true = [[1,0],[0,1] will return [0.2, 0.1]
        # shape = (batch_size, )
        pos_min = (
            tf.reduce_min(  # the reduce min takes the only value when label are 1-hot
                tf.where(y_true == 1, y_pred, y_pred.dtype.max), axis=-1
            )
        )
        values, classes = tf.math.top_k(y_pred, k=self.k)
        # compute the difference between the "positive" logit and each "negative" to compute margins
        # shape = (batch_size, nb_classes)
        # example:
        # in the previous example, margins would be [[0, -0.3], [0.2, 0]]
        ordered_margins = (
            tf.repeat(tf.expand_dims(pos_min, axis=-1), self.k, axis=-1) - values
        )
        # now we compute the hinge term (we want to maximize the margins)
        # we use the smoothed version of hinge so gradient of the loss is always defined
        # # as the loss is defined with margin = 1, we use the min_margin to scale the values
        # ordered_hinge = tf.where(
        #         ordered_margins <= 0,
        #         0.5 - ordered_margins / self.min_margin,
        #         0.5 * tf.square(tf.nn.relu(1.0 - ordered_margins / self.min_margin)),
        #     )
        ordered_hinge = (
            tf.nn.relu(self.min_margin - ordered_margins) - self.alpha * ordered_margins
        )
        discounted_hinge = tf.multiply(
            ordered_hinge,
            tf.repeat(tf.expand_dims(self.gammas, axis=0), tf.shape(y_pred)[0], axis=0),
        )
        hinge_term = tf.reduce_mean(discounted_hinge)
        # # this multiplicative factor ensure that the loss gradient is in [alpha, 1]
        # # hinge = hinge * self.min_margin / (1 + self.alpha)
        # # now we compute the wasserstein term, as we want the margin to be positive
        # # we only keep the mean of margins
        # wass = tf.reduce_mean(pos_min, axis=0) - tf.reduce_mean(values) # should be values != pos_min
        # # return the loss value
        # loss = -wass * self.alpha + hinge_term
        # return loss
        return hinge_term

    def get_config(self):
        config = {
            "alpha": self.alpha,
            "min_margin": self.min_margin,
            "k": self.k,
            "discount_factor": self.discount_factor,
        }
        return config
