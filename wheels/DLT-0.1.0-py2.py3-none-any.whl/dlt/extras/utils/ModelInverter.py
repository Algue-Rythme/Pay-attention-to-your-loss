import tensorflow as tf
from tensorflow.keras.models import Model, Sequential
from tensorflow.keras.layers import (
    Input,
    InputLayer,
    Flatten,
    Layer,
    Lambda,
    Dense,
    Conv2D,
    MaxPool2D,
    AveragePooling2D,
    Conv2DTranspose,
    UpSampling2D,
    Reshape,
    LeakyReLU,
    Activation,
)
from tensorflow.keras.activations import sigmoid
from tensorflow.keras import backend as K
from deel.lip.layers import SpectralDense, SpectralConv2D, ScaledAveragePooling2D
from deel.lip.activations import MaxMin
from deel.lip.model import vanillaModel
from deel.lip.layers import InvertibleDownSampling, InvertibleUpSampling


def invert_sequential(sequential: Sequential):
    """inverts sequential model"""
    # input of inverted model is the output of the original model
    layers = [Input(sequential.output_shape[1:])]
    # iterate layers from the end
    for layer in sequential.layers[::-1]:
        layers += invert_layer(layer)
    # build the model
    out_model = Sequential(layers=layers, name="{}_inv".format(sequential.name))
    # out_model.build(sequential.output_shape[1:])
    out_model.built = True
    # transfer kernels for dense eand conv layers
    for layer in sequential.layers:
        if isinstance(layer, Dense):
            out_model.get_layer(
                name="{}_inv".format(layer.name)
            ).kernel = tf.linalg.pinv(layer.kernel, rcond=None)
        if isinstance(layer, Conv2D):
            out_model.get_layer(name="{}_inv".format(layer.name)).kernel = tf.identity(
                layer.kernel
            )
    return out_model


def invert_sequential_stepped(sequential: Sequential):
    """inverts sequential model"""
    outputs = []
    # input of inverted model is the output of the original model
    inputs = Input(sequential.input_shape[1:])
    x = tf.identity(inputs)
    # iterate layers from the end
    for layer in sequential.layers:
        x = layer(x)
        outputs.append(tf.identity(x))
    for i, layer in enumerate(sequential.layers[::-1]):
        for inv_l in invert_layer(layer):
            x = inv_l(x)
            for j in range(i + 1):
                outputs[-(j + 1)] = inv_l(outputs[-(j + 1)])
    # build the model
    out_model = Model(inputs, outputs, name="{}_inv".format(sequential.name))
    out_model.build(sequential.output_shape[1:])
    # transfer kernels for dense eand conv layers
    for layer in sequential.layers:
        if isinstance(layer, Dense):
            out_model.get_layer(
                name="{}_inv".format(layer.name)
            ).kernel = tf.linalg.pinv(layer.kernel)
        if isinstance(layer, Conv2D):
            out_model.get_layer(name="{}_inv".format(layer.name)).kernel = tf.identity(
                layer.kernel
            )
    return out_model


def invert_layer(lay: Layer):
    """
    Select the appropriate function to call to invert the layer, depending on it's type
    """
    if isinstance(lay, Dense) or isinstance(lay, SpectralDense):
        return invert_dense(lay)
    if isinstance(lay, Conv2D) or isinstance(lay, SpectralConv2D):
        return invert_conv(lay)
    if (
        isinstance(lay, AveragePooling2D)
        or isinstance(lay, ScaledAveragePooling2D)
        or isinstance(lay, MaxPool2D)
    ):
        return invert_avgpool(lay)
    if isinstance(lay, InvertibleDownSampling):
        return invert_invertibledownsampling(lay)
    if isinstance(lay, LeakyReLU):
        return invert_leaky_relu(lay)
    if isinstance(lay, MaxMin):
        return invert_maxmin(lay)
    if isinstance(lay, Flatten):
        return invert_flatten(lay)
    if isinstance(lay, InputLayer):
        return []
    if isinstance(lay, Sequential):
        return [invert_sequential(lay)]
    raise RuntimeError("layer class not invertible: {}".format(lay.__class__.__name__))


def invert_activation_by_name(act):
    if act.__name__ == "sigmoid":
        return invert_sigmoid(act)
    if act.__name__ == "tanh":
        return invert_tanh(act)
    if act.__name__ == "linear":
        return []
    raise RuntimeError("layer activation not invertible: {}".format(act.__name__))


def invert_dense(lay: Dense) -> [Layer]:
    """
    invert a dense layer, converting it into a sequence of 3 operations
    1. apply inverse of the activation
    2. remove bias
    3. apply kernel pseudo inverse
    """
    out_lay_list = []
    if "activation" in lay.get_config():
        if not (isinstance(lay.activation, tf.keras.activations.linear.__class__)):
            out_lay_list += invert_layer(lay.activation)
        else:
            out_lay_list += invert_activation_by_name(lay.activation)
    if hasattr(lay, "use_bias") and lay.use_bias:
        out_lay_list.append(
            Lambda(lambda x: x - lay.bias, name="{}_inv_bias".format(lay.name))
        )
    # inv_dense.kernel = tf.linalg.pinv(lay.kernel)
    out_lay_list.append(
        Dense(
            lay.input_shape[-1],
            activation=None,
            use_bias=False,
            name="{}_inv".format(lay.name),
        )
    )
    return out_lay_list


def invert_sigmoid(lay: sigmoid):
    return [Lambda(lambda x: tf.math.log(x / (1 - x)))]


def invert_tanh(lay):
    return [Lambda(lambda x: 0.5 * tf.math.log((1 + x) / (1 - x)))]


def invert_conv(lay: Conv2D) -> [Layer]:
    """
    invert a conv layer, converting it into a sequence of 3 operations
    1. apply inverse of the activation
    2. remove bias
    3. apply convTranspose operation
    """
    out_lay_list = []
    if "activation" in lay.get_config() and not (
        isinstance(lay.activation, tf.keras.activations.linear.__class__)
    ):
        out_lay_list += invert_layer(lay.activation)
    if hasattr(lay, "use_bias") and lay.use_bias:
        out_lay_list.append(
            Lambda(
                lambda x: K.bias_add(x, -lay.bias, data_format=lay.data_format),
                name=f"{lay.name}_inv_bias",
            )
        )
    # inv_conv.kernel = tf.identity(lay.kernel)
    out_lay_list.append(
        Conv2DTranspose(
            filters=lay.input_shape[-1],
            kernel_size=lay.kernel_size,
            strides=lay.strides,
            padding=lay.padding,
            activation=None,
            use_bias=False,
            name="{}_inv".format(lay.name),
        )
    )
    return out_lay_list


def invert_avgpool(lay: ScaledAveragePooling2D) -> [Layer]:
    """
    invert average pooling, converting it into upsampling layer
    """
    RuntimeWarning(
        "use of avg/max pooling is deprecated, consider using invertibleDownsampling instead"
    )
    out_lay_list = []
    if hasattr(lay, "_get_coef"):
        out_lay_list.append(Lambda(lambda x: x / lay._get_coef()))
    out_lay_list.append(UpSampling2D(lay.pool_size))
    return out_lay_list


def invert_invertibledownsampling(lay: InvertibleDownSampling) -> [Layer]:
    """
    invert average pooling, converting it into upsampling layer
    """
    out_lay_list = []
    out_lay_list.append(InvertibleUpSampling(lay.pool_size))
    return out_lay_list


def invert_leaky_relu(lay: LeakyReLU) -> [Layer]:
    """inverse of leakyRelu (alpha) is LeakyRelu(1/alpha)"""
    return [LeakyReLU(1 / lay.alpha)]


def invert_maxmin(lay: MaxMin) -> [Layer]:
    """MaxMin is invertible, by removing negative component to positie component"""
    input_shape = lay._build_input_shape
    if len(input_shape) == 2:
        return [
            Lambda(
                lambda x: K.relu(x[:, : input_shape[-1]])
                - K.relu(x[:, input_shape[-1] :])
            )
        ]
    if len(input_shape) == 3:
        return [
            Lambda(
                lambda x: K.relu(x[:, :, : input_shape[-1]])
                - K.relu(x[:, :, input_shape[-1] :])
            )
        ]
    if len(input_shape) == 4:
        return [
            Lambda(
                lambda x: K.relu(x[:, :, :, : input_shape[-1]])
                - K.relu(x[:, :, :, input_shape[-1] :])
            )
        ]


def invert_flatten(lay: Flatten) -> [Layer]:
    """flatten can be inverted by using a reshape"""
    return [Reshape(lay.input_shape[1:])]


if __name__ == "__main__":
    from deel.lip.activations import MaxMin
    import numpy as np

    x = np.random.uniform(-1, 1, (5, 28, 28, 3))
    l11 = MaxMin()
    l1 = MaxMin()
    l1.build((5, 28, 28, 3))
    l2 = invert_maxmin(l1)[0]
    l11.build((5, 10))
    l22 = invert_maxmin(l11)[0]
    x = np.random.uniform(-1, 1, (5, 28, 28, 3))
    x2 = np.random.uniform(-1, 1, (5, 10))
    print(np.allclose(l22(l11(x2)), x2))
    print(np.allclose(l2(l1(x)), x))

    alpha = 0.5
    l3 = LeakyReLU(alpha)
    l4 = LeakyReLU(1 / alpha)
    print(np.allclose(l4(l3(x2)), x2))
    print(np.allclose(l4(l3(x)), x))

    l5 = Flatten()
    l6 = Reshape((28, 28, 3))
    x2 = np.random.uniform(-1, 1, (5, 28 * 28 * 3))
    print(np.allclose(l5(l6(x2)), x2))
    print(np.allclose(l6(l5(x)), x))

    """create a model (f), train it on MNIST, invert it (f^-1), and compute f(f^-1(x))"""
    multiclass_model = Sequential(
        layers=[
            Input(shape=(28, 28, 1)),  # dim 784
            # Lambda(tf.math.l2_normalize),
            # InvertibleDownSampling(pool_size=(2, 2)),  # 14,14,4 -> 784
            SpectralConv2D(
                filters=4,
                strides=(1, 1),
                kernel_size=(3, 3),
                use_bias=False,
                padding="same",
                name="conv11",
                bias_initializer="glorot_normal",
                kernel_initializer="orthogonal",
                activation=LeakyReLU(0.6),
            ),
            SpectralConv2D(
                filters=4,
                strides=(1, 1),
                kernel_size=(3, 3),
                use_bias=False,
                padding="same",
                name="conv12",
                bias_initializer="glorot_normal",
                kernel_initializer="orthogonal",
                activation=LeakyReLU(0.6),
            ),  # 14,14,2 -> 392
            InvertibleDownSampling(pool_size=(2, 2)),  # 7,7,8 -> 392
            SpectralConv2D(
                filters=8,
                strides=(1, 1),
                kernel_size=(3, 3),
                use_bias=False,
                padding="same",
                name="conv21",
                bias_initializer="glorot_normal",
                kernel_initializer="orthogonal",
                activation=LeakyReLU(0.6),
            ),
            SpectralConv2D(
                filters=8,
                strides=(1, 1),
                kernel_size=(3, 3),
                use_bias=False,
                padding="same",
                name="conv22",
                bias_initializer="glorot_normal",
                kernel_initializer="orthogonal",
                activation=LeakyReLU(0.6),
            ),  # 7,7,4 -> 196
            Flatten(),
            SpectralDense(
                128,
                use_bias=True,
                activation=LeakyReLU(),
                bias_initializer="glorot_normal",
                kernel_initializer="orthogonal",
                name="dense2",
                trainable=True,
            ),
            SpectralDense(
                64,
                use_bias=True,
                activation=LeakyReLU(),
                bias_initializer="glorot_normal",
                kernel_initializer="orthogonal",
                name="dense1",
                trainable=True,
            ),
            SpectralDense(
                10,
                use_bias=True,
                activation="sigmoid",
                bias_initializer="glorot_normal",
                kernel_initializer="orthogonal",
                name="logits",
                trainable=True,
            ),
        ],
        name="hkr",
        # lbda=1,
    )

    from tensorflow.keras.datasets import mnist
    from tensorflow.keras.utils import to_categorical
    from deel.lip.losses import HKR_multiclass_loss
    from deel.lip.utils import load_model

    (x_train, y_train_ord), (x_test, y_test_ord) = mnist.load_data()
    # Make sure images have shape (28, 28, 1)
    x_train = tf.convert_to_tensor(x_train / 256.0, dtype="float32")
    x_test = tf.convert_to_tensor(x_test / 256.0, dtype="float32")
    x_train = tf.expand_dims(x_train, -1)
    x_test = tf.expand_dims(x_test, -1)
    # convert class vectors to binary class matrices
    y_train = to_categorical(y_train_ord, 10)
    # y_train = tf.convert_to_tensor((y_train * 2.0) - 1.0, dtype="float32")
    y_test = to_categorical(y_test_ord, 10)
    # y_test = tf.convert_to_tensor((y_test * 2.0) - 1.0, dtype="float32")

    # multiclass_model = load_model("invertible_VGG_cifar10.h5",
    #                               custom_objects={
    #                                   "InvertibleDownSampling": InvertibleDownSampling,
    #                               }
    #                               )
    multiclass_model.compile(
        tf.keras.optimizers.Adam(0.005),
        loss="binary_crossentropy",
        metrics=["accuracy"],
    )
    multiclass_model.summary()
    # compute_vs([0, 1, 3, 4], multiclass_model)

    vanilla_multiclass = vanillaModel(multiclass_model)
    vanilla_multiclass.summary()
    inv_model = invert_sequential(vanilla_multiclass)
    inv_model.summary()
    print("#" * 30)
    print("before training")
    print("#" * 30)
    f = lambda x: vanilla_multiclass(inv_model(x))
    x = vanilla_multiclass(
        x_train[:255]
    )  # np.random.uniform(0, 1, (255, inv_model.input_shape[-1]))
    print(f"x sampled from dataset : {np.average(np.abs(f(x) - x))}")
    x = np.random.uniform(0, 1, (255, inv_model.input_shape[-1]))
    print(f"x sampled from logits : {np.average(np.abs(f(x) - x))}")
    u = np.zeros(((255,) + vanilla_multiclass.input_shape[1:]))
    x = vanilla_multiclass(u)
    print(f"x sampled from inputs : {np.average(np.abs(f(x) - x))}")
    # u = np.random.uniform(0, 1, ((255,) + vanilla_multiclass.input_shape[1:]))
    u = np.zeros(((255,) + vanilla_multiclass.input_shape[1:]))
    u[:, 3:-3, 3:-3, :] = np.random.uniform(0, 1, (255, 22, 22, 1))
    x = vanilla_multiclass(u)
    print(f"x sampled from inputs (with padding): {np.average(np.abs(f(x) - x))}")

    multiclass_model.fit(
        x_train, y_train, 1000, epochs=2, validation_data=(x_test, y_test)
    )

    print("#" * 30)
    print("after training")
    print("#" * 30)
    # multiclass_model.save("invertible_model.h5")
    # inv_model = invert_sequential_stepped(vanillaModel(multiclass_model))
    vanilla_multiclass = vanillaModel(multiclass_model)
    vanilla_multiclass.summary()
    inv_model = invert_sequential(vanilla_multiclass)
    inv_model.summary()
    f = lambda x: vanilla_multiclass(inv_model(x))

    x = vanilla_multiclass(
        x_train[:255]
    )  # np.random.uniform(0, 1, (255, inv_model.input_shape[-1]))
    print(f"x sampled from dataset : {np.average(np.abs(f(x) - x))}")
    x = np.random.uniform(0, 0.99, (255, inv_model.input_shape[-1]))
    print(f"x sampled from logits : {np.average(np.abs(f(x) - x))}")
    u = np.zeros(((255,) + vanilla_multiclass.input_shape[1:]))
    x = vanilla_multiclass(u)
    print(f"x sampled from inputs : {np.average(np.abs(f(x) - x))}")
    # u = np.random.uniform(0, 1, ((255,) + vanilla_multiclass.input_shape[1:]))
    u = np.zeros(((255,) + vanilla_multiclass.input_shape[1:]))
    u[:, 3:-3, 3:-3, :] = np.random.uniform(0, 1, (255, 22, 22, 1))
    x = vanilla_multiclass(u)
    print(f"x sampled from inputs (with padding): {np.average(np.abs(f(x) - x))}")
    # x2 = multiclass_model(inv_model(x))

    # import matplotlib.pyplot as plt
    # import numpy as np
    # nb_ex = 10
    # y = inv_model(x_train[:nb_ex])
    # plt.imshow(
    #     np.hstack(
    #         [
    #             np.vstack(
    #                 [y[j][i, :, :, 0] for i in range(nb_ex)]
    #             )
    #             for j in range(len(y))
    #         ]
    #     )
    # )
    # plt.show()
    # #plt.imshow(np.vstack(inv_model(to_categorical(range(10))*2 - 1)[i, :, :, 0] for i in range(10)))
    # #plt.show()
