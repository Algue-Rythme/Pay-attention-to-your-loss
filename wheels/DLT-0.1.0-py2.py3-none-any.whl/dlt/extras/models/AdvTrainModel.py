from abc import ABC

import tensorflow as tf
from tensorflow.keras import Model, Sequential
from tensorflow.keras.utils import unpack_x_y_sample_weight


class AdvTrainModel(Model, ABC):
    def __init__(self, inputs, outputs, name=None, m=4, eps=0.02):
        super(AdvTrainModel, self).__init__(inputs, outputs, name)
        self.m = m
        self.eps = eps

    def build(self, input_shape=None):
        built_model = super().build(input_shape)
        self.x_p = self.add_weight(
            "x_p", shape=input_shape, dtype=self.input.dtype, initializer="zero"
        )
        return built_model

    def train_step(self, data):
        return train_step(self, data)

    def get_config(self):
        config = {"m": self.m, "eps": self.eps}
        base_config = super(AdvTrainModel, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


class AdvTrainSequential(Sequential):
    def __init__(self, layers=None, name=None, m=4, eps=0.02):
        super(AdvTrainSequential, self).__init__(layers, name)
        self.m = m
        self.eps = eps

    def build(self, input_shape=None):
        built_model = super().build(input_shape)
        self.x_p = self.add_weight(
            "x_p", shape=input_shape, dtype=self.input.dtype, initializer="zero"
        )
        return built_model

    def train_step(self, data):
        return train_step(self, data)

    def get_config(self):
        config = {"m": self.m, "eps": self.eps}
        base_config = super(AdvTrainSequential, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


def train_step(self, data):
    # These are the only transformations `Model.fit` applies to user-input
    # data when a `tf.data.Dataset` is provided. These utilities will be exposed
    # publicly.
    x, y, sample_weight = unpack_x_y_sample_weight(data)
    delta = tf.zeros_like(x)
    for i in range(self.m):
        self.x_p.assign(x + delta)
        with tf.GradientTape() as tape:
            y_pred = self(self.x_p, training=True)
            loss = self.compiled_loss(
                y, y_pred, sample_weight, regularization_losses=self.losses
            )
        # For custom training steps, users can just write:
        trainable_variables = self.trainable_variables + [self.x_p]
        g = tape.gradient(loss, trainable_variables)
        g_theta = g[:-1]
        g_delta = g[-1]
        self.optimizer.apply_gradients(zip(g_theta, trainable_variables))
        delta = delta + self.eps * tf.sign(g_delta)
        delta = tf.clip_by_value(delta, -self.eps, self.eps)

    self.compiled_metrics.update_state(y, y_pred, sample_weight)
    return {m.name: m.result() for m in self.metrics}
