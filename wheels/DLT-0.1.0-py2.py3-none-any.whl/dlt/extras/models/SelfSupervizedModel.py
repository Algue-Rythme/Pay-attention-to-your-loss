from abc import ABC

import tensorflow as tf
from tensorflow.keras.utils import register_keras_serializable
from tensorflow.keras import Model, Sequential


@register_keras_serializable("dlt", "SelfSupervizedModel")
class SelfSupervizedModel(Model, ABC):
    def __init__(self, inputs, outputs, name=None):
        super(SelfSupervizedModel, self).__init__(inputs, outputs, name)
        self.batch_len_metric = BatchSizeMetric()

    def build(self, input_shape=None):
        built_model = super().build(input_shape)
        return built_model

    def train_step(self, data):
        if self.output_shape[-1] == 1:
            return binary_train_step(self, data)
        else:
            return train_step(self, data)

    def get_config(self):
        config = {}
        base_config = super(SelfSupervizedModel).get_config()
        return dict(list(base_config.items()) + list(config.items()))


@register_keras_serializable("dlt", "SelfSupervizedSequential")
class SelfSupervizedSequential(Sequential):
    def __init__(self, layers=None, name=None):
        super(SelfSupervizedSequential, self).__init__(layers, name)
        self.batch_len_metric = BatchSizeMetric()

    def build(self, input_shape=None):
        built_model = super().build(input_shape)
        return built_model

    def train_step(self, data):
        if self.output_shape[-1] == 1:
            return binary_train_step(self, data)
        else:
            return train_step(self, data)

    def get_config(self):
        config = {}
        base_config = super(SelfSupervizedSequential, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


class BatchSizeMetric:
    def __init__(self):
        self.batch_len = 0
        self.name = "batch_size"

    def update_state(self, y_true, y_pred):
        self.batch_len = tf.shape(y_true)[0]

    def result(self):
        return self.batch_len


def extract_data(data):
    a, b = data
    if isinstance(a, tuple) and (len(a) == 2):
        x, y = a
        x_unlab = b
    else:
        x, y = a, b
        x_unlab = None
    return x, y, x_unlab


def train_step(self, data):
    # These are the only transformations `Model.fit` applies to user-input
    # data when a `tf.data.Dataset` is provided. These utilities will be exposed
    # publicly.
    x, y, x_unlabelled = extract_data(data)
    with tf.GradientTape() as tape:
        # Run the forward pass of the layer.
        # The operations that the layer applies
        # to its inputs are going to be recorded
        # on the GradientTape.
        # Run the forward pass of the layer.
        # The operations that the layer applies
        # to its inputs are going to be recorded
        # on the GradientTape.
        logits = self(x, training=True)  # Logits for this minibatch

        if x_unlabelled is not None:
            # compute the margin_threshold
            values_lab, indices_lab = tf.math.top_k(logits, 2)
            margin = values_lab[:, 0] - values_lab[:, 1]
            threshold = tf.reduce_mean(margin) + tf.math.reduce_std(margin)
            # compute the loss for unlabelled data
            logits_unlabelled = self(
                x_unlabelled, training=True
            )  # Logits for this minibatch
            # select items with sufficient margin
            values, indices = tf.math.top_k(logits_unlabelled, 2)
            logits_unlabelled_large_margin = tf.boolean_mask(
                logits_unlabelled, (values[:, 0] - values[:, 1]) > threshold, axis=0
            )
            assigned_y = tf.where(
                tf.equal(
                    logits_unlabelled_large_margin,
                    tf.repeat(
                        tf.expand_dims(
                            tf.reduce_max(logits_unlabelled_large_margin, -1), -1
                        ),
                        logits_unlabelled_large_margin.shape[-1],
                        axis=-1,
                    ),
                ),
                1.0,
                0.0,
            )
            # compte the
            # loss_value_unlabelled = self.compiled_loss(assigned_y, logits_unlabelled_large_margin)
            # weak_sup_loss = loss_value + self.weight * loss_value_unlabelled
            loss_value = self.compiled_loss(
                tf.concat([y, assigned_y], axis=0),
                tf.concat([logits, logits_unlabelled_large_margin], axis=0),
            )
        else:
            # Compute the loss value for this minibatch.
            loss_value = self.compiled_loss(y, logits)
    # Use the gradient tape to automatically retrieve
    # the gradients of the trainable variables with respect to the loss.
    grads = tape.gradient(loss_value, self.trainable_weights)

    # Run one step of gradient descent by updating
    # the value of the variables to minimize the loss.
    self.optimizer.apply_gradients(zip(grads, self.trainable_weights))
    if x_unlabelled is not None:
        self.compiled_metrics.update_state(
            tf.concat([y, assigned_y], axis=0),
            tf.concat([logits, logits_unlabelled_large_margin], axis=0),
        )
        self.batch_len_metric.update_state(assigned_y, logits_unlabelled_large_margin)
        return {m.name: m.result() for m in self.metrics + [self.batch_len_metric]}
    else:
        self.compiled_metrics.update_state(y, logits)
    return {m.name: m.result() for m in self.metrics}


def binary_train_step(self, data):
    # These are the only transformations `Model.fit` applies to user-input
    # data when a `tf.data.Dataset` is provided. These utilities will be exposed
    # publicly.
    x, y, x_unlabelled = extract_data(data)
    with tf.GradientTape() as tape:
        # Run the forward pass of the layer.
        # The operations that the layer applies
        # to its inputs are going to be recorded
        # on the GradientTape.
        # Run the forward pass of the layer.
        # The operations that the layer applies
        # to its inputs are going to be recorded
        # on the GradientTape.
        logits = self(x, training=True)  # Logits for this minibatch

        if x_unlabelled is not None:
            # compute the margin_threshold
            threshold_pos = tf.reduce_mean(tf.boolean_mask(logits, y > 0))
            threshold_neg = tf.reduce_mean(tf.boolean_mask(logits, y < 0))
            # compute the loss for unlabelled data
            logits_unlabelled = self(
                x_unlabelled, training=True
            )  # Logits for this minibatch
            # select items with sufficient margin
            logits_unlabelled_large_margin = tf.boolean_mask(
                logits_unlabelled,
                tf.logical_or(
                    logits_unlabelled > threshold_pos, logits_unlabelled < threshold_neg
                ),
            )
            assigned_y = tf.cast(tf.sign(logits_unlabelled_large_margin), y.dtype)
            # compte the
            # loss_value_unlabelled = self.compiled_loss(assigned_y, logits_unlabelled_large_margin)
            # weak_sup_loss = loss_value + self.weight * loss_value_unlabelled
            logits_unlabelled_large_margin = tf.expand_dims(
                logits_unlabelled_large_margin, axis=-1
            )
            loss_value = self.compiled_loss(
                tf.concat([y, assigned_y], axis=0),
                tf.concat([logits, logits_unlabelled_large_margin], axis=0),
            )
        else:
            # Compute the loss value for this minibatch.
            loss_value = self.compiled_loss(y, logits)
    # Use the gradient tape to automatically retrieve
    # the gradients of the trainable variables with respect to the loss.
    grads = tape.gradient(loss_value, self.trainable_weights)

    # Run one step of gradient descent by updating
    # the value of the variables to minimize the loss.
    self.optimizer.apply_gradients(zip(grads, self.trainable_weights))
    if x_unlabelled is not None:
        self.compiled_metrics.update_state(
            tf.concat([y, assigned_y], axis=0),
            tf.concat([logits, logits_unlabelled_large_margin], axis=0),
        )
        self.batch_len_metric.update_state(assigned_y, logits_unlabelled_large_margin)
        return {m.name: m.result() for m in self.metrics + [self.batch_len_metric]}
    else:
        self.compiled_metrics.update_state(y, logits)
    return {m.name: m.result() for m in self.metrics}
