from abc import ABC

import tensorflow as tf
from tensorflow.keras import Model, Sequential
from tensorflow.keras.utils import unpack_x_y_sample_weight


class GradientPenaltyModel(Model, ABC):
    def __init__(self, inputs, outputs, name=None, lbda=1, eps=1e-8):
        super(GradientPenaltyModel, self).__init__(inputs, outputs, name)
        self.lbda = lbda
        self.eps = eps

    def build(self, input_shape=None):
        built_model = super().build(input_shape)
        return built_model

    def train_step(self, data):
        return train_step(self, data)

    def get_config(self):
        config = {"lbda": self.lbda, "eps": self.eps}
        base_config = super(GradientPenaltyModel, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


class GradientPenaltySequential(Sequential):
    def __init__(self, layers=None, name=None, lbda=1, eps=1e-8):
        super(GradientPenaltySequential, self).__init__(layers, name)
        self.lbda = lbda
        self.eps = eps

    def build(self, input_shape=None):
        built_model = super().build(input_shape)
        return built_model

    def train_step(self, data):
        return train_step(self, data)

    def get_config(self):
        config = {"lbda": self.lbda, "eps": self.eps}
        base_config = super(GradientPenaltySequential, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


def train_step(self, data):
    # These are the only transformations `Model.fit` applies to user-input
    # data when a `tf.data.Dataset` is provided. These utilities will be exposed
    # publicly.
    x, y, sample_weight = unpack_x_y_sample_weight(data)
    with tf.GradientTape() as tape:
        y_pred = self(x, training=True)
        grad = tf.gradients(y_pred, x)[0]
        slopes = tf.sqrt(
            self.eps
            + tf.reduce_sum(tf.square(grad), axis=range(1, len(self.input_shape)))
        )
        gradient_penalty = tf.reduce_mean((slopes - 1.0) ** 2)
        loss = self.compiled_loss(
            y, y_pred, sample_weight, regularization_losses=self.losses
        )
        pen_loss = loss + self.lbda * gradient_penalty
    # For custom training steps, users can just write:
    trainable_variables = self.trainable_variables
    g = tape.gradient(pen_loss, trainable_variables)
    self.optimizer.apply_gradients(zip(g, trainable_variables))

    self.compiled_metrics.update_state(y, y_pred, sample_weight)
    return {m.name: m.result() for m in self.metrics}
