from abc import ABC

import tensorflow as tf
from tensorflow.keras import Model
from tensorflow.keras.utils import register_keras_serializable


@register_keras_serializable("dlt", "WassersteinRegularizedModel")
class WassersteinRegularizedModel(Model, ABC):
    def __init__(
        self,
        feat_extractor: Model,
        classifier: Model,
        wass_estimator: Model,
        wass_weight=1.0,
        name=None,
    ):
        super(WassersteinRegularizedModel, self).__init__(name)
        self.feat_extractor = feat_extractor
        self.classifier = classifier
        self.wass_estimator = wass_estimator
        self.wass_weight = wass_weight

    @staticmethod
    def GRL(hp_lambda):
        @tf.custom_gradient
        def id_op(x):
            def grad(dy):
                return -dy * hp_lambda

            return tf.identity(x), grad

        return id_op

    def compile(
        self,
        classif_optimizer="rmsprop",
        classif_loss=None,
        classif_metrics=None,
        wass_optimizer="rmsprop",
        wass_loss=None,
        wass_metrics=None,
        loss_weights=None,
        weighted_metrics=None,
        run_eagerly=None,
        **kwargs,
    ):
        self.feat_extractor.compile(
            classif_optimizer,
            classif_loss,
            classif_metrics,
            loss_weights=loss_weights,
            weighted_metrics=weighted_metrics,
            run_eagerly=run_eagerly,
        )
        self.classifier.compile(
            classif_optimizer,
            classif_loss,
            classif_metrics,
            loss_weights=loss_weights,
            weighted_metrics=weighted_metrics,
            run_eagerly=run_eagerly,
        )
        self.wass_estimator.compile(
            wass_optimizer,
            wass_loss,
            wass_metrics,
            loss_weights=loss_weights,
            weighted_metrics=weighted_metrics,
            run_eagerly=run_eagerly,
        )
        return super(WassersteinRegularizedModel, self).compile(
            loss=classif_loss, metrics=classif_metrics
        )

    def build(self, input_shape):
        self.feat_extractor.build(input_shape)
        self.classifier.build(self.feat_extractor.output_shape)
        self.wass_estimator.build(self.feat_extractor.output_shape)
        self.built = True

    def call(self, inputs, training=None, mask=None):
        return self.classifier.call(
            self.feat_extractor.call(inputs, training, mask), training, mask
        )

    def train_step(self, data):
        # These are the only transformations `Model.fit` applies to user-input
        # data when a `tf.data.Dataset` is provided. These utilities will be exposed
        # publicly.
        (x, y), x_unlabelled = data
        with tf.GradientTape() as tape:
            # Run the forward pass of the layer.
            # The operations that the layer applies
            # to its inputs are going to be recorded
            # on the GradientTape.
            features = self.feat_extractor(x, training=True)
            features_unlab = self.feat_extractor(x, training=True)
            logits = self.classifier(
                features, training=True
            )  # Logits for this minibatch
            wass_pos = self.wass_estimator(
                self.GRL(self.wass_weight)(features), training=True
            )
            wass_neg = self.wass_estimator(
                self.GRL(self.wass_weight)(features_unlab), training=True
            )

            # wass_loss_val = - (tf.nn.relu(tf.reduce_mean(wass_pos)) + tf.nn.relu(- tf.reduce_mean(wass_neg)))
            wass_loss_val = self.wass_estimator.compiled_loss(
                tf.concat(
                    [
                        tf.ones((tf.shape(features)[0],)),
                        tf.zeros((tf.shape(features_unlab)[0],)),
                    ],
                    axis=0,
                ),
                tf.concat([wass_pos, wass_neg], axis=0),
            )  # tf.reduce_mean(wass_pos) - tf.reduce_mean(wass_neg)
            loss_val = self.classifier.compiled_loss(y, logits) + wass_loss_val
        # Use the gradient tape to automatically retrieve
        # the gradients of the trainable variables with respect to the loss.
        grads = tape.gradient(
            loss_val,
            self.feat_extractor.trainable_weights
            + self.classifier.trainable_weights
            + self.wass_estimator.trainable_weights,
        )

        # Run one step of gradient descent by updating
        # the value of the variables to minimize the loss.
        grads = [tf.math.l2_normalize(tf.sign(g)) for g in grads]
        self.classifier.optimizer.apply_gradients(
            zip(
                grads,
                self.feat_extractor.trainable_weights
                + self.classifier.trainable_weights
                + self.wass_estimator.trainable_weights,
            )
        )
        self.classifier.compiled_metrics.update_state(y, logits)
        self.wass_estimator.compiled_metrics.update_state(
            tf.concat(
                [
                    tf.ones((tf.shape(features)[0],)),
                    tf.zeros((tf.shape(features_unlab)[0],)),
                ],
                axis=0,
            ),
            tf.concat([wass_pos, wass_neg], axis=0),
        )
        res = dict()
        res.update({f"class_{m.name}": m.result() for m in self.classifier.metrics})
        res.update({f"wass_{m.name}": m.result() for m in self.wass_estimator.metrics})
        return res

    def get_config(self):
        config = {
            "feat_extractor": self.feat_extractor,
            "classifier": self.classifier,
            "wass_estimator": self.wass_estimator,
            "wass_weight": self.wass_weight,
        }
        base_config = super(WassersteinRegularizedModel).get_config()
        return dict(list(base_config.items()) + list(config.items()))
