"""
This module contains tools to handle datasets. This module contains 3 main submodules:

- loader: function to load data, each function returns a tuple (ds_train, ds_test,
  metadata), the two first are tensorflow datasets, and metadata is a dict containing
  `nb_classes`, `input_shape`, `nb_sample_train`, `nb_sample_test`.
- augmentation: function to augment the data, each work sample-wise (unbatched)
- pipeline: contains utility functions to make pipeline with custom
  preparation/augmentation. Utility to make balanced datasets, or specific
  augmentation as mixup.

"""
from . import augmentation
from . import autoaugment
from . import loader
from . import pipeline
from . import utils
