from typing import Callable
import tensorflow as tf


def prepare_data(
    ds_train,
    ds_test,
    preparation_x=None,
    preparation_y=None,
    augmentation_x=None,
    batch_size=512,
):
    """

    Performs standard preparation on datasets:

    - preparation of data (rescaling, one_hot encoding...)
    - augmentation (only on train data)
    - shuffling of data (only on train data)
    - batching and prefetching of data

    Args:
        ds_train: train dataset as a tf.data.Dataset
        ds_test: test dataset
        preparation_x: list of functions to apply to prepare data features
            (ex convert dtype)
        preparation_y: list of functions to apply to prepare data labels
            (ex one_hot encoding)
        augmentation_x: list of functions to augment data features (ex rotation,
            contrast)
        batch_size: batch size to use in the dataset

    Returns:
        two batched and prefeteched datasets, with preparation and augmentation (
        when appropriate), for train and test.

    """
    # build preparation and augmentation sequences
    augmentation_x_fct = get_sequence_x(augmentation_x)
    preparation_x_fct = get_sequence_x(preparation_x)
    preparation_y_fct = get_sequence_y(preparation_y)
    # apply pipeline: preparation > shuffle > augmentation > batch > prefetch
    ds_train = (
        ds_train.map(preparation_x_fct, num_parallel_calls=tf.data.AUTOTUNE)
        .map(preparation_y_fct, num_parallel_calls=tf.data.AUTOTUNE)
        .shuffle(
            min(batch_size * 50, max(100, ds_train.cardinality())),
            reshuffle_each_iteration=True,
        )
        .map(augmentation_x_fct, num_parallel_calls=tf.data.AUTOTUNE)
        .batch(batch_size)
        .prefetch(tf.data.AUTOTUNE)
    )
    ds_test = (
        ds_test.map(preparation_x_fct, num_parallel_calls=tf.data.AUTOTUNE)
        .map(preparation_y_fct, num_parallel_calls=tf.data.AUTOTUNE)
        .shuffle(
            min(batch_size * 50, max(100, ds_test.cardinality())),
            reshuffle_each_iteration=True,
        )
        .batch(batch_size)
        .prefetch(tf.data.AUTOTUNE)
    )
    return ds_train, ds_test


def mixup_prepare_data(
    ds_train, ds_test, preparation_x, preparation_y, augmentation_x, batch_size
):
    """

    Performs standard preparation on datasets, with mixup data augmentation:

    - preparation of data (rescaling, one_hot encoding...)
    - augmentation (only on train data)
    - shuffling of data (only on train data)
    - batching and prefetching of data

    Args:
        ds_train: train dataset as a tf.data.Dataset
        ds_test: test dataset
        preparation_x: list of functions to apply to prepare data features
            (ex convert dtype)
        preparation_y: list of functions to apply to prepare data labels
            (ex one_hot encoding)
        augmentation_x: list of functions to augment data features (ex rotation,
            contrast)
        batch_size: batch size to use in the dataset

    Returns:
        two batched and prefeteched datasets, with preparation and augmentation (
        when appropriate), for train and test.

    """

    # build preparation and augmentation sequences
    augmentation_x_fct = get_sequence_x(augmentation_x)
    preparation_x_fct = get_sequence_x(preparation_x)
    preparation_y_fct = get_sequence_y(preparation_y)
    # apply pipeline: preparation > shuffle > augmentation > batch > prefetch

    def sample_beta_distribution(size, concentration_0, concentration_1):
        gamma_1_sample = tf.random.gamma(shape=[size], alpha=concentration_1)
        gamma_2_sample = tf.random.gamma(shape=[size], alpha=concentration_0)
        return gamma_1_sample / (gamma_1_sample + gamma_2_sample)

    def mix_up(ds_one, ds_two, alpha=0.2):
        # Unpack two datasets
        images_one, labels_one = ds_one
        images_two, labels_two = ds_two
        batch_size = tf.shape(images_one)[0]

        # Sample lambda and reshape it to do the mixup
        l = sample_beta_distribution(batch_size, alpha, alpha)
        x_l = tf.reshape(l, (batch_size, 1, 1, 1))
        y_l = tf.reshape(l, (batch_size, 1))

        # Perform mixup on both images and labels by combining a pair of images/labels
        # (one from each dataset) into one image/label
        images = images_one * x_l + images_two * (1 - x_l)
        labels = labels_one * y_l + labels_two * (1 - y_l)
        return (images, labels)

    def cast(x, y):
        x = tf.cast(x, tf.float32)
        return x, y

    ds_train1 = (
        ds_train.map(preparation_x_fct, num_parallel_calls=tf.data.AUTOTUNE)
        .map(preparation_y_fct, num_parallel_calls=tf.data.AUTOTUNE)
        .shuffle(batch_size * 100, reshuffle_each_iteration=True)
        .map(augmentation_x_fct, num_parallel_calls=tf.data.AUTOTUNE)
        .map(cast, num_parallel_calls=tf.data.AUTOTUNE)
        .batch(batch_size)
        .prefetch(tf.data.AUTOTUNE)
    )
    ds_train2 = (
        ds_train.map(preparation_x_fct, num_parallel_calls=tf.data.AUTOTUNE)
        .map(preparation_y_fct, num_parallel_calls=tf.data.AUTOTUNE)
        .shuffle(batch_size * 100, reshuffle_each_iteration=True)
        .map(augmentation_x_fct, num_parallel_calls=tf.data.AUTOTUNE)  # nothing
        # specified
        .map(cast, num_parallel_calls=tf.data.AUTOTUNE)
        # regarding augmentation of the second dataset...
        .batch(batch_size)
        .prefetch(tf.data.AUTOTUNE)
    )
    train_ds = tf.data.Dataset.zip((ds_train1, ds_train2))
    train_ds_mu = train_ds.map(
        lambda ds_one, ds_two: mix_up(ds_one, ds_two, alpha=0.2),
        num_parallel_calls=tf.data.AUTOTUNE,
    )

    ds_test = (
        ds_test.map(preparation_x_fct, num_parallel_calls=tf.data.AUTOTUNE)
        .map(preparation_y_fct, num_parallel_calls=tf.data.AUTOTUNE)
        .shuffle(batch_size * 100, reshuffle_each_iteration=True)
        .batch(batch_size)
        .prefetch(tf.data.AUTOTUNE)
    )
    return train_ds_mu, ds_test


def semisup_prepare_data(
    ds_train,
    ds_test,
    preparation_x,
    preparation_y,
    augmentation_x,
    batch_size,
    to_keep,
    seed,
):
    """
    Load data from dataset object and create 3 balanced datasets objects: lablelled,
    unlabelled and test. Balancing is done by picking sequentially one element of
    each class in order. The split between labelled and unlabelled is done such that
    the labelled dataset contains an equal amount of elements from each class ( this
    ensure to have at least one element of each class when to_keep value is very low).

    Args:
        ds_train: train dataset as a tf.data.Dataset
        ds_test: test dataset
        preparation_x: list of functions to apply to prepare data features
            (ex convert dtype)
        preparation_y: list of functions to apply to prepare data labels
            (ex one_hot encoding)
        augmentation_x: list of functions to augment data features (ex rotation,
            contrast)
        batch_size: batch size to use in the dataset
        to_keep: number of sample to keep as labelled data, other sample will have
            their labels discarded.
        seed: seed used to split labelled and unlabelled samples.

    Returns:
        a tuple with labelled, unlabelled and test dataset

    """

    # build preparation and augmentation sequences
    augmentation_x_fct = get_sequence_x(augmentation_x)
    preparation_x_fct = get_sequence_x(preparation_x)
    preparation_y_fct = get_sequence_y(preparation_y)

    # shuffle and split train data SEED NEED TO BE FIXED !
    ds_train.shuffle(2 * batch_size * 100, seed, reshuffle_each_iteration=False).map(
        preparation_x_fct, num_parallel_calls=tf.data.AUTOTUNE
    ).map(preparation_y_fct, num_parallel_calls=tf.data.AUTOTUNE)
    # split data
    ds_labelled = ds_train.take(to_keep).cache().repeat()
    ds_unlabelled = ds_train.skip(to_keep).cache()
    # apply augmentation on trained labelled data
    ds_labelled = (
        ds_labelled.map(augmentation_x_fct, num_parallel_calls=tf.data.AUTOTUNE)
        .batch(batch_size)
        .prefetch(tf.data.AUTOTUNE)
    )
    # apply augmentation but also drop labels on unlabelled data
    ds_unlabelled = (
        ds_unlabelled.map(augmentation_x_fct, num_parallel_calls=tf.data.AUTOTUNE)
        .map(lambda x, y: x, num_parallel_calls=tf.data.AUTOTUNE)
        .batch(batch_size)
        .prefetch(tf.data.AUTOTUNE)
    )
    # apply preparation but no augmentation on test data
    ds_test = (
        ds_test.map(preparation_x_fct, num_parallel_calls=tf.data.AUTOTUNE)
        .map(preparation_y_fct, num_parallel_calls=tf.data.AUTOTUNE)
        .shuffle(batch_size * 100, reshuffle_each_iteration=True)
        .batch(batch_size)
        .prefetch(tf.data.AUTOTUNE)
    )

    return ds_labelled, ds_unlabelled, ds_test


def balanced(ds, nb_classes, buffer_size):
    """
    Build balanced dataset. Balancing is performed by taking sequentially items from
    class 0,1,2,3... so that each batch containt an even number of elements of each
    class.

    Args:
        ds: a tensorflow dataset object containing the data
        nb_classes: number of classe of the problem
        buffer_size: size of the buffer used to shuffle elements from eahc class

    Returns:
        a dataset object with re-ordered elements

    """
    return tf.data.experimental.choose_from_datasets(
        [
            ds.filter(lambda features, label: label == i).shuffle(buffer_size)
            for i in range(nb_classes)
        ],
        tf.data.Dataset.range(nb_classes).repeat(),
    )


def get_sequence(funcs):
    """
    Construct a sequence of augmentations.

    Args:
        *funcs: list of augmentation functions, must take only (x, y) as input.
            can be either, None (no augmentation), a callable (single augmentation function)
            or a list, eventually empty of functions (sequence of augmentations)

    """
    if funcs is None:
        funcs = []

    if isinstance(funcs, Callable):
        funcs = [funcs]

    @tf.function
    def sequence(x, y):
        for func in funcs:
            x, y = func(x, y)
        return x, y

    return sequence


def get_sequence_x(funcs):
    """
    Construct a sequence of augmentations.

    Args:
        *funcs: list of augmentation functions, must take only x as input.
            can be either, None (no augmentation), a callable (single augmentation function)
            or a list, eventually empty of functions (sequence of augmentations)

    """
    if funcs is None:
        funcs = []

    if isinstance(funcs, Callable):
        funcs = [funcs]

    @tf.function
    def sequence(x, y):
        for func in funcs:
            x = func(x)
        return x, y

    return sequence


def get_sequence_y(funcs):
    """
    Construct a sequence of augmentations.

    Args:
        *funcs: list of augmentation functions, must take only y as input.
            can be either, None (no augmentation), a callable (single augmentation function)
            or a list, eventually empty of functions (sequence of augmentations)

    """
    if funcs is None:
        funcs = []

    if isinstance(funcs, Callable):
        funcs = [funcs]

    @tf.function
    def sequence(x, y):
        for func in funcs:
            y = func(y)
        return x, y

    return sequence


def generic_augmentation_wrapper(func, *args, **kwargs):
    """

    Wraps an augmentation function that only takes an x and turns it into a function
    that takes an (x, y)

    Args:
        func: function to apply
        *args: params given when calling func
        **kwargs: params given when calling func

    """

    @tf.function
    def aug(x, y):
        x = func(x, *args, **kwargs)
        return x, y

    return aug
