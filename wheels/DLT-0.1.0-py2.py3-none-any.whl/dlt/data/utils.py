"""
Utility module, used in the data.loader module.
"""
import tensorflow as tf


def get_metadata(ds):
    """
    Extract metadata from a tensorflow dataset.
    This function returns a dict whose keys are:
        - input_shape : Tuple. input shape, without batch_size
        - nb_classes : int. number of classes
        - nb_samples_train : int. number of samples in train set
        - nb_samples_test : int. set to -1 as only train set is given to the function
        - class_names : None as class names cannot be inferred with this function

    Args:
        ds: a tensorflow dataset

    Returns:
        A dict with dataset metadata.

    """
    return {
        "input_shape": ds.element_spec[0].shape,
        "nb_classes": tf.reduce_max(
            list(ds.take(10000).map(lambda x, y: y).as_numpy_iterator())
        )
        + 1,
        "nb_samples_train": ds.map(lambda x, y: y).cardinality().numpy(),
        "nb_samples_test": -1,
        "class_names": None,
    }


def get_metadata_from_ds_info(ds_info):
    """
    Extract metadata from a tensorflow dataset information object. Such info is
    obtained when the param `with_info` is set to `True` in the `tfds.load()` function.
    This function returns a dict whose keys are:
        - input_shape : Tuple. input shape, without batch_size
        - nb_classes : int. number of classes
        - nb_samples_train : int. number of samples in train set
        - nb_samples_test : int. number of samples in test set
        - class_names : array(string). mapping between labels and class names

    Args:
        ds: a tensorflow dataset

    Returns:
        A dict with dataset metadata.
    """
    try:
        nb_samples_test = ds_info.splits["test"].num_examples
    except:
        nb_samples_test = ds_info.splits["validation"].num_examples

    return {
        "input_shape": ds_info.features["image"].shape,
        "nb_classes": ds_info.features["label"].num_classes,
        "nb_samples_train": ds_info.splits["train"].num_examples,
        "nb_samples_test": nb_samples_test,
        "class_names": ds_info.features['label'].names,
    }
