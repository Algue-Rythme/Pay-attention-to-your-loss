import tensorflow as tf

_MAX_LEVEL = 10.0


def batched_fn(fn):
    """
    Annotation that can be added to any function to make it work on batched instead
    of single images.

    Args:
        fn: function to wrap expected to have x (images) as first argument. Other
            arguments are supported.

    Returns:
        fn that handle batches instead of independent elements

    """
    def batched_fn(x, *args, **kwargs):
        return tf.map_fn(lambda x: fn(x, *args, **kwargs), x)

    return batched_fn


def aug_layer(fn, *args, **kwargs):
    """
    Wrapper that ease the use of augmentations inside pipelines. It works like a
    partial, but the arguments when called are added at the beginning.

    .. code-block:: python

        def some_aug_fct(x, param1, param2):
            ...
            return x_augmented

        l = aug_layer(some_aug_fct, value1, param2=value2)
        x_augmented = l(x)

    Args:
        fn: augmentation function to wrap. Expected to have a tensor as its first
            argument (the image tensor to augment). Other arguments can be set as
            desired.
        *args: other arguments, in the correct order. Must not contain x.
        **kwargs: other, in the kwargs fashion. Must not contain x.

    Returns:
        a wrapped function that only requires the x argument.

    """
    return lambda x: fn(x, *args, **kwargs)


def _blend(image1, image2, factor):
    """Blend image1 and image2 using 'factor'.

    Factor can be above 0.0.  A value of 0.0 means only image1 is used.
    A value of 1.0 means only image2 is used.  A value between 0.0 and
    1.0 means we linearly interpolate the pixel values between the two
    images.  A value greater than 1.0 "extrapolates" the difference
    between the two pixel values, and we clip the results to values
    between 0 and 255.

    Args:
      image1: An image Tensor of type uint8.
      image2: An image Tensor of type uint8.
      factor: A floating point value above 0.0.

    Returns:
      A blended image Tensor of type uint8.
    """
    original_dtype = image1.dtype
    if factor == 0.0:
        return tf.convert_to_tensor(image1)
    if factor == 1.0:
        return tf.convert_to_tensor(image2)

    image1 = tf.cast(image1, dtype=tf.float32)
    image2 = tf.cast(image2, dtype=tf.float32)

    difference = image2 - image1
    scaled = factor * difference

    # Do addition in float.
    temp = tf.cast(image1, dtype=tf.float32) + scaled

    # discard this, so factor can be an array when the function is called on a batch
    # of data
    # # Interpolate
    # if factor > 0.0 and factor < 1.0:
    #     # Interpolation means we always stay within 0 and 255.
    #     return tf.cast(temp, tf.uint8)

    # Extrapolate:
    #
    # We need to clip and then cast.
    clip_high = 1.0 if original_dtype.is_floating else 255.0
    return tf.cast(tf.clip_by_value(temp, 0.0, clip_high), original_dtype)