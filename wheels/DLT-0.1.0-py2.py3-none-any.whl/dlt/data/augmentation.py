"""
module containing augmentations. Every augmentation has been tested with uint8 (0 to
255) and float32 (0 to 1) image. These functions has been tested with single images (
map applied before batching ).

Functions comes in two variants:

- apply_* : apply the transformation with fixed parameters
- random_* : apply a transformation with random parameters

"""
from collections import defaultdict
import tensorflow as tf
import tensorflow_addons as tfa
import numpy as np
from dlt.data.augmentation_utils import _blend
from tensorflow_addons import image as contrib_image

random_hue = tf.image.random_hue
"""
Alias of `tf.image.random_hue`.

.. image:: augmentation/random_hue.png
"""
apply_hue = tf.image.adjust_hue
"""Alias of `tf.image.adjust_hue`."""

random_flip_left_right = tf.image.random_flip_left_right
"""
Alias of `tf.image.random_flip_left_right`.

.. image:: augmentation/random_flip_left_right.png
"""
apply_flip_left_right = tf.image.flip_left_right
"""Alias of `tf.image.flip_left_right`."""

random_flip_up_down = tf.image.random_flip_up_down
"""
Alias of `tf.image.random_flip_up_down`.

.. image:: augmentation/random_flip_up_down.png
"""
apply_flip_up_down = tf.image.flip_up_down
"""Alias of `tf.image.flip_up_down`."""
random_jpeg_quality = tf.image.random_jpeg_quality
"""
Alias of `tf.image.random_jpeg_quality`.

.. image:: augmentation/random_jpeg_quality.png
"""
apply_jpeg_quality = tf.image.adjust_jpeg_quality
"""Alias of `tf.image.adjust_jpeg_quality`."""
apply_brightness = tf.image.adjust_brightness
"""Alias of `tf.image.adjust_brightness`."""
apply_contrast = tf.image.adjust_contrast
"""Alias of `tf.image.adjust_contrast`."""
apply_saturation = tf.image.adjust_saturation
"""Alias of `tf.image.adjust_saturation`."""


# copy of the original function with improved documentation.
def random_brightness(image, max_delta, seed=None):
    """Adjust the brightness of images by a random factor.

    Equivalent to `adjust_brightness()` using a `delta` randomly picked in the
    interval `[-max_delta, max_delta)`.

    This is a convenience method that converts RGB images to float
    representation, adjusts their brightness, and then converts them back to the
    original data type. If several adjustments are chained, it is advisable to
    minimize the number of redundant conversions.

    The value `delta` is added to all components of the tensor `image`. `image` is
    converted to `float` and scaled appropriately if it is in fixed-point
    representation, and `delta` is converted to the same data type. For regular
    images, `delta` should be in the range `(-1,1)`, as it is added to the image
    in floating point representation, where pixel values are in the `[0,1)` range.

    .. image:: augmentation/random_brightness.png

    Args:
      image: An image or images to adjust.
      max_delta: float, must be non-negative.
      seed: A Python integer. Used to create a random seed. See
        `tf.compat.v1.set_random_seed` for behavior.

    Usage Example:

    >>> x = [[[1.0, 2.0, 3.0],
    ...       [4.0, 5.0, 6.0]],
    ...      [[7.0, 8.0, 9.0],
    ...       [10.0, 11.0, 12.0]]]
    >>> tf.image.random_brightness(x, 0.2)
    <tf.Tensor: shape=(2, 2, 3), dtype=float32, numpy=...>

    Returns:
      The brightness-adjusted image(s).

    Raises:
      ValueError: if `max_delta` is negative.
    """
    return tf.image.random_brightness(image, max_delta, seed)


# copy of the original function with improved documentation.
def random_contrast(image, lower, upper, seed=None):
    """Adjust the contrast of an image or images by a random factor.

    Equivalent to `adjust_contrast()` but uses a `contrast_factor` randomly
    picked in the interval `[lower, upper)`. When values are less than 1.0 the
    image loose it's contrast, when values are greater than 1.0, the image is more
    contrasted. Lower must be greater than 0.

    This is a convenience method that converts RGB images to float
    representation, adjusts their contrast, and then converts them back to the
    original data type. If several adjustments are chained, it is advisable to
    minimize the number of redundant conversions.

    `images` is a tensor of at least 3 dimensions.  The last 3 dimensions are
    interpreted as `[height, width, channels]`.  The other dimensions only
    represent a collection of images, such as `[batch, height, width, channels].`

    Contrast is adjusted independently for each channel of each image.

    For each channel, this Op computes the mean of the image pixels in the
    channel and then adjusts each component `x` of each pixel to
    `(x - mean) * contrast_factor + mean`.

    .. image:: augmentation/random_contrast.png

    Args:
      image: An image tensor with 3 or more dimensions.
      lower: float.  Lower bound for the random contrast factor.
      upper: float.  Upper bound for the random contrast factor.
      seed: A Python integer. Used to create a random seed. See
        `tf.compat.v1.set_random_seed` for behavior.

    Usage Example:

    >>> x = [[[1.0, 2.0, 3.0],
    ...       [4.0, 5.0, 6.0]],
    ...     [[7.0, 8.0, 9.0],
    ...       [10.0, 11.0, 12.0]]]
    >>> tf.image.random_contrast(x, 0.2, 0.5)
    <tf.Tensor: shape=(2, 2, 3), dtype=float32, numpy=...>

    Returns:
      The contrast-adjusted image(s).

    Raises:
      ValueError: if `upper <= lower` or if `lower < 0`.
    """
    return tf.image.random_contrast(image, lower, upper, seed)


# copy of the original function with improved documentation.
def random_saturation(image, lower, upper, seed=None):
    """Adjust the saturation of RGB images by a random factor.

    Equivalent to `adjust_saturation()` but uses a `saturation_factor` randomly
    picked in the interval `[lower, upper)`. When the value is less than 1.0 the
    image is desaturated (grayscale) when the value is greater than 1.0 the image
    is saturated (more vivid colors).

    This is a convenience method that converts RGB images to float
    representation, converts them to HSV, adds an offset to the
    saturation channel, converts back to RGB and then back to the original
    data type. If several adjustments are chained it is advisable to minimize
    the number of redundant conversions.

    `image` is an RGB image or images.  The image saturation is adjusted by
    converting the images to HSV and multiplying the saturation (S) channel by
    `saturation_factor` and clipping. The images are then converted back to RGB.

    .. image:: augmentation/random_saturation.png

    Usage Example:

    >>> x = [[[1.0, 2.0, 3.0],
    ...       [4.0, 5.0, 6.0]],
    ...     [[7.0, 8.0, 9.0],
    ...       [10.0, 11.0, 12.0]]]
    >>> tf.image.random_saturation(x, 5, 10)
    <tf.Tensor: shape=(2, 2, 3), dtype=float32, numpy=
    array([[[ 0. ,  1.5,  3. ],
            [ 0. ,  3. ,  6. ]],
           [[ 0. ,  4.5,  9. ],
            [ 0. ,  6. , 12. ]]], dtype=float32)>

    Args:
      image: RGB image or images. The size of the last dimension must be 3.
      lower: float.  Lower bound for the random saturation factor.
      upper: float.  Upper bound for the random saturation factor.
      seed: An operation-specific seed. It will be used in conjunction with the
        graph-level seed to determine the real seeds that will be used in this
        operation. Please see the documentation of set_random_seed for its
        interaction with the graph-level random seed.

    Returns:
      Adjusted image(s), same shape and DType as `image`.

    Raises:
      ValueError: if `upper <= lower` or if `lower < 0`.
    """
    return tf.image.random_saturation(image, lower, upper, seed)


def randaugment(
    x,
    nb_layers=2,
    magnitude=5,
    remove_augmentations=[],
    extra_augmentations={},
    extra_kwargs={},
):
    """
    Randaugment. Uses input in both [0, 255] and [0, 1].

    Randomly pick `nb_layers` augmentations and apply those with `magnitude`. The
    magnitude of 10 is the strongest magnitude. The following list show the used
    augmentations, and the parameter range when magnitude ranges from 0 to 10.

    - identity: no parameters
    - random_autocontrast: no parameters
    - random_equalize: no parameters
    - random_invert: no parameters
    - random_rotate: rotation from 0 to 30 degrees
    - random_posterize: from 0 to 4 dropped bits
    - random_solarize: threshold from 0 to 256 ( works similar on [0,1] inputs )
    - random_solarize_add: addition from 0 to 110 ( works similar on [0,1] inputs )
      threshold is kept at 128.
    - random_color: `max_factor` ranging from 0.1 to 1.0
    - random_contrast: `lower` and `upper` ranging from (1.0, 1.0) to (0.2, 1.8).
    - random_brightness: `max_factor` ranging from 0.1 to 0.6
    - random_sharpness: `max_factor` ranging from 0. to 1.0
    - random_shear_x: `max_factor` ranging from 0. to 0.3
    - random_shear_y: `max_factor` ranging from 0. to 0.3
    - random_cutout: when level=0 no cutout is applied, when level=10, a quarter of
      the image is removed
    - random_translate_x: when level=0 no shift is applied, when level=10, the shift
      can be up to `0.4*image_size`.
    - random_translate_y: when level=0 no shift is applied, when level=10, the shift
      can be up to `0.4*image_size`.

    Notes:
        For some reasons, some augmentations, sur as `random_hue`, or `random_flip`,
        and `random_resizedcrop` are missing.

        There are some differences in the implementations between the original
        randaugment and this code:

            - level conversion for color, constrast, brightness, sharpness initially
              range from 0.1 et 1.8 which could yield degenerated images (totally
              black or totally white for random_brightness for instance).
            - level conversion for cutout and translate have been changed to a
              proportion of the image size. This allow to remove cumbersome hparams
              in the original version.
            - transformations in randaugment were always applied with maximum
              magnitude (`apply_*` behavior). In this implementation values are
              chosen uniformly up maximum magnitude (`random_*` behavior).

    Args:
        nb_layers: number of augmentations to apply simultaneously
        magnitude: intensity of the augmentation
        remove_augmentations: list of functions pointers, allowing to remove a
            function from the augmentation list.
        extra_augmentations: dict allowing to add augmentations. Must be a dict
            where keys are pointer to the augmentation functions and values are
            functions that takes (level, input_shape) and returns the augmentation
            *args. For example, to add the hue augmentation, with max_delta=0.25 when
            level = 10 you can set:

            .. highlight:: python
            .. code-block:: python

                extra_augmentations = {
                    random_hue: lambda level, img_shape: 0.25 * level / 10.
                }

            Already existing augmentations will override default ones (allowing to
            override the level to arg function).
        extra_kwargs: a dict containing the kwargs that will overide parameter of
            ougmentations. For instance if you which to change the `fill_mode` of the
            shear_x function the following `extra_kwargs` could be setted:

            .. highlight:: python
            .. code-block:: python

                extra_kwargs = {
                    random_shear_x: {"fill_mode":"constant", "fill_value":0}
                }

    .. image:: augmentation/randaugment.png

    """
    _MAX_LEVEL = 10
    # build augmentation_list
    augmentations = {
        tf.identity: lambda level, img_shape: (),
        random_autocontrast: lambda level, img_shape: (),
        random_equalize: lambda level, img_shape: (),
        random_invert: lambda level, img_shape: (),
        random_rotate: lambda level, img_shape: ((level / _MAX_LEVEL) * 30.0,),
        random_posterize: lambda level, img_shape: (int((level / _MAX_LEVEL) * 4),),
        random_solarize: lambda level, img_shape: (int((level / _MAX_LEVEL) * 256),),
        random_solarize_add: lambda level, img_shape: (
            int((level / _MAX_LEVEL) * 110),
        ),
        random_color: lambda level, img_shape: ((level / _MAX_LEVEL) * 0.8 + 0.1,),
        random_contrast: lambda level, img_shape: (
            -(level / _MAX_LEVEL) * 0.8 + 1.0,
            (level / _MAX_LEVEL) * 0.8 + 1.0,
        ),
        random_brightness: lambda level, img_shape: ((level / _MAX_LEVEL) * 0.5 + 0.1,),
        random_sharpness: lambda level, img_shape: ((level / _MAX_LEVEL),),
        random_shear_x: lambda level, img_shape: ((level / _MAX_LEVEL) * 0.3,),
        random_shear_y: lambda level, img_shape: ((level / _MAX_LEVEL) * 0.3,),
        random_cutout: lambda level, img_shape: (
            int(level / _MAX_LEVEL * 0.25 * img_shape[1]),
        ),
        random_translate_x: lambda level, img_shape: (
            int((level / _MAX_LEVEL) * 0.4 * img_shape[1]),
        ),
        random_translate_y: lambda level, img_shape: (
            int((level / _MAX_LEVEL) * 0.4 * img_shape[1]),
        ),
    }
    # remove the remove_augmentations
    for key in remove_augmentations:
        augmentations.pop(key, None)
    # add the extra_augmentations
    augmentations.update(extra_augmentations)
    # add the kwargs
    aug_kwargs = defaultdict(lambda: {})
    aug_kwargs.update(extra_kwargs)
    # apply the augmentations
    for layer_num in range(nb_layers):
        op_to_select = tf.random.uniform([], maxval=len(augmentations), dtype=tf.int32)
        with tf.name_scope("randaug_layer_{}".format(layer_num)):
            for (i, (op_fct, level_fct)) in enumerate(augmentations.items()):
                args = level_fct(magnitude, x.shape)
                kwargs = aug_kwargs[op_fct]
                x = tf.cond(
                    tf.equal(i, op_to_select),
                    # pylint:disable=g-long-lambda
                    lambda selected_func=op_fct, selected_args=args: selected_func(
                        x, *selected_args, **kwargs
                    ),
                    # pylint:enable=g-long-lambda
                    lambda: x,
                )
    return x


def random_rotate(x, max_rotation, interpolation="nearest", fill_mode="nearest"):
    """

    Rotate images randomly with an angle ranging -max_rotation to + max_rotation.
    Rotations are sampled from uniforms.

    .. image:: augmentation/random_rotate.png

    Args:
        max_rotation: float: maximum rotation in degrees.
        interpolation: interpolation used in `tfa.image.rotate`
        fill_mode: fill mode used in `tfa.image.rotate`
    """
    rot = np.pi * max_rotation / 180.0
    if len(x.shape) == 4:
        random_angles = tf.random.uniform(
            shape=(tf.shape(x)[0],), minval=-rot, maxval=rot
        )
        x = tfa.image.rotate(
            x, random_angles, interpolation=interpolation, fill_mode=fill_mode
        )
    if len(x.shape) == 3:
        random_angles = tf.random.uniform(shape=(), minval=-rot, maxval=rot)

        x = tfa.image.rotate(
            x, random_angles, interpolation=interpolation, fill_mode=fill_mode
        )
    return x


@tf.function
def apply_rotate(x, rotation, interpolation="nearest", fill_mode="nearest"):
    """
    Rotate images. rotation is in degrees.
    Rotations are sampled from uniforms.

    Args:
        rotation: float: rotation in degrees.
        interpolation: interpolation used in `tfa.image.rotate`
        fill_mode: fill mode used in `tfa.image.rotate`
    """
    rot = np.pi * rotation / 180.0
    x = tfa.image.rotate(x, rot, interpolation=interpolation, fill_mode=fill_mode)
    return x


def random_resizedcrop(
    x,
    scale=(0.5, 1.0),
    ratio=(3.0 / 4.0, 4.0 / 3.0),
    out_shape=None,
    interpolation="bilinear",
):
    """
    Randomly crop a window in the image and resize it to original size and shape.

    .. image:: augmentation/random_resizedcrop.png

    Args:
        x: images to augment; can be either a 2D or a 3D tensor
        scale: the scale range of the crop. The crop will cover an area between
            (low, high)
        ratio: the maximum aspect ratio of the crop, as the crop are not necessarly
            squares
        interpolation: the interpolation methods used to resize the image back to
            original shape

    Notes:
        This is the only function that don't have a apply_resizecrop. This is because
        the random parameters are interdependent (the location of the crop depends on
        the size of and ratio of the crop).

    Returns:
        the augmented images

    """
    single_image = len(tf.shape(x)) == 3
    if single_image:
        x = tf.expand_dims(x, axis=0)
    bs = tf.shape(x)[0]
    h = tf.cast(tf.shape(x)[1], dtype=tf.float32)
    w = tf.cast(tf.shape(x)[2], dtype=tf.float32)
    if out_shape is None:
        out_shape = (h, w)
    dtype = x.dtype
    # 1. compute target area
    scale_sample = tf.random.uniform((bs,), tf.sqrt(scale[0]), tf.sqrt(scale[1]))
    # 2. choose ratio such that it can be resized
    aspect_ratio = tf.random.uniform((bs,), *ratio)
    # 3. compute width and height
    bw = tf.minimum(w * scale_sample / aspect_ratio, w)
    bh = tf.minimum(h * scale_sample * aspect_ratio, h)
    # 4. compute center
    i = tf.random.uniform((bs,), 0, h - bh)
    j = tf.random.uniform((bs,), 0, w - bw)
    # 5. compute boxes
    x1 = i / h
    x2 = (i + bh) / h
    y1 = j / w
    y2 = (j + bw) / w
    boxes = tf.stack([y1, x1, y2, x2], axis=-1)
    x = tf.image.crop_and_resize(
        x, boxes, tf.range(bs), out_shape, method=interpolation
    )
    return tf.cast(tf.squeeze(x, axis=0), dtype)


def random_cutout(image, pad_size, fill_mode="average", fill_value=None):
    """Apply cutout (https://arxiv.org/abs/1708.04552) to image.

    This operation applies a (2*pad_size x 2*pad_size) mask of zeros to
    a random location within `img`. The pixel values filled in will be of the
    value `replace`. The located where the mask will be applied is randomly
    chosen uniformly over the whole image.

    .. image:: augmentation/random_cutout.png

    Args:
        image: An 3D image Tensor of type uint8.
        pad_size: Specifies how big the zero mask that will be generated is that
            is applied to the image. The mask will be of size
            (2*pad_size x 2*pad_size).
        fill_mode: filling mode for the part removed by cutout, one of ["average",
            "constant"]
        fill_value: when fill_mode is constant, the value o use for filling.

    Returns:
      An image Tensor that is of type uint8.
    """
    image_height = tf.shape(image)[0]
    image_width = tf.shape(image)[1]
    # Sample the center location in the image where the zero mask will be applied.
    cutout_center_height = tf.random.uniform(
        shape=[], minval=0, maxval=image_height, dtype=tf.int32
    )
    cutout_center_width = tf.random.uniform(
        shape=[], minval=0, maxval=image_width, dtype=tf.int32
    )
    return apply_cutout(
        image,
        pad_size,
        cutout_center_height,
        cutout_center_width,
        fill_mode,
        fill_value,
    )


@tf.function
def apply_cutout(
    image,
    pad_size,
    cutout_center_height,
    cutout_center_width,
    fill_mode="average",
    fill_value=None,
):
    """Apply cutout (https://arxiv.org/abs/1708.04552) to image.

    This operation applies a (2*pad_size x 2*pad_size) mask of zeros to
    the defined location within `img`. The pixel values filled in will be of the
    value `replace`.

    Args:
        image: An 3D image Tensor of type uint8.
        pad_size: Specifies how big the zero mask that will be generated is that
            is applied to the image. The mask will be of size
            (2*pad_size x 2*pad_size).
        cutout_center_height: int : height of the center of the cutout pad.
        cutout_center_width: int : width of the center of the cutout pad.
        fill_mode: filling mode for the part removed by cutout, one of ["average",
            "constant"]
        fill_value: when fill_mode is constant, the value o use for filling.

    Returns:
      An image Tensor that is of type uint8.
    """
    if fill_mode not in ["constant", "average"]:
        raise RuntimeError('invalid fill mode, must be one of ["average","constant"]')
    image_height = tf.shape(image)[0]
    image_width = tf.shape(image)[1]

    # Sample the center location in the image where the zero mask will be applied.
    lower_pad = tf.maximum(0, cutout_center_height - pad_size)
    upper_pad = tf.maximum(0, image_height - cutout_center_height - pad_size)
    left_pad = tf.maximum(0, cutout_center_width - pad_size)
    right_pad = tf.maximum(0, image_width - cutout_center_width - pad_size)

    cutout_shape = [
        image_height - (lower_pad + upper_pad),
        image_width - (left_pad + right_pad),
    ]
    padding_dims = [[lower_pad, upper_pad], [left_pad, right_pad]]
    mask = tf.pad(
        tf.zeros(cutout_shape, dtype=image.dtype), padding_dims, constant_values=1
    )
    mask = tf.expand_dims(mask, -1)
    mask = tf.tile(mask, [1, 1, 3])
    if fill_mode == "average":
        image = tf.where(
            tf.equal(mask, 0),
            tf.cast(
                tf.ones_like(image, dtype=tf.float32)
                * tf.reduce_sum(
                    tf.cast(image * (1 - mask), dtype=tf.float32), axis=[0, 1]
                )
                / (2 * pad_size) ** 2,
                dtype=image.dtype,
            ),
            image,
        )
    elif fill_mode == "constant":
        image = image * mask + fill_value * (1 - mask)
    return image


def random_solarize(image, threshold=128):
    """
    For each pixel in the image, select the pixel
    if the value is less than the threshold.
    Otherwise, subtract 255 from the pixel.
    This operation is performed with a probability of 0.5.

    .. image:: augmentation/random_solarize.png

    Args:
        image: the image to augment, can be a 3D of a 4D tensor of type uint8 or
            float32.
        threshold: threshold to use in solarization

    Returns:
        the solarized images

    """
    bs = _get_batch_size(image)
    factor = tf.random.uniform((bs,), 0, 1)[0]
    return tf.where(factor > 0.5, apply_solarize(image, threshold), image)


@tf.function
def apply_solarize(image, threshold=128):
    """
    For each pixel in the image, select the pixel
    if the value is less than the threshold.
    Otherwise, subtract 255 from the pixel.

    Args:
        image: the image to augment, can be a 3D of a 4D tensor of type uint8 or
            float32.
        threshold: threshold to use in solarization

    Returns:
        the solarized images

    """
    img_dtype = image.dtype
    if img_dtype.is_floating:
        return tf.where(image < threshold / 255.0, image, 1.0 - image)
    return tf.where(image < threshold, image, 255 - image)


def random_solarize_add(image, addition=32, threshold=128):
    """
    For each pixel in the image less than threshold
    we add 'addition' amount to it and then clip the
    pixel value to be between 0 and 255. The value
    of 'addition' is between -128 and 128.

    .. image:: augmentation/random_solarize_add.png

    """
    bs = _get_batch_size(image)
    factor = tf.cast(tf.random.uniform((bs,), 0, addition)[0], tf.int64)
    return apply_solarize_add(image, factor, threshold)


@tf.function
def apply_solarize_add(image, addition=32, threshold=128):
    """
    For each pixel in the image less than threshold
    we add 'addition' amount to it and then clip the
    pixel value to be between 0 and 255. The value
    of 'addition' is between -128 and 128.

    """
    img_dtype = image.dtype
    if img_dtype.is_floating:
        image = tf.image.convert_image_dtype(image, tf.uint8)
    added_image = tf.cast(image, tf.int64) + addition
    added_image = tf.cast(tf.clip_by_value(added_image, 0, 255), image.dtype)
    return tf.cast(
        tf.where(image < threshold, added_image, image),
        img_dtype,
    )


def random_color(image, max_factor):
    """
    Equivalent of PIL Color.

    .. image:: augmentation/random_color.png

    Args:
        image: the image to augment, can be a 3D of a 4D tensor of type uint8.
        max_factor: effect intensity, 0 means no change, one means the image is
            grayscale.

    Returns: return a blend between the original image and it's grayscale version

    """
    bs = _get_batch_size(image)
    factor = tf.random.uniform((bs,), 0, max_factor)
    return apply_color(image, factor)


@tf.function
def apply_color(image, factor):
    """
    Equivalent of PIL Color.

    Args:
        image: the image to augment, can be a 3D of a 4D tensor of type uint8.
        factor: effect intensity, 0 means no change, one means the image is
            grayscale.

    Returns: return a blend between the original image and it's grayscale version

    """
    degenerate = tf.image.grayscale_to_rgb(tf.image.rgb_to_grayscale(image))
    return _blend(image, degenerate, factor)


def random_posterize(image, max_bits):
    """
    Equivalent of PIL Posterize. Drops the last bits of each value of the image.

    .. image:: augmentation/random_posterize.png

    Args:
        image: the image to augment, a 3D or 4D tensor of type uint8 or float32.
        max_bits: max_number of dropped bits can be at most 8.

    Warning:
        This function only works with int data.

    """
    bs = _get_batch_size(image)
    bits = tf.cast(tf.random.uniform((bs,), 0, max_bits), tf.uint8)[0]
    return apply_posterize(image, bits)


@tf.function
def apply_posterize(image, bits):
    """
    Equivalent of PIL Posterize. Drops the last bits of each value of the image.

    Args:
        image: the image to augment, a 3D or 4D tensor of type uint8 or float32.
        bits: number of dropped bits can be at most 8.

    Warning:
        This function only works with int data.

    """
    shift = tf.clip_by_value(bits, 0, 8)
    orig_dtype = image.dtype
    image = tf.image.convert_image_dtype(image, tf.uint8)
    return tf.image.convert_image_dtype(
        tf.bitwise.left_shift(tf.bitwise.right_shift(image, shift), shift),
        orig_dtype,
    )


def random_translate_x(image, max_pixels, fill_mode="nearest", fill_value=0.0):
    """
    Equivalent of PIL Translate in X dimension.

    .. image:: augmentation/random_translate_x.png

    Args:
        images: the image to augment, a 3D or 4D tensor of type uint8 or float32.
        max_pixels: int: max pixel displacement on the y axis.
        fill_mode: Points outside the boundaries of the input are filled according to
            the given mode (one of `{'constant', 'reflect', 'wrap', 'nearest'}`)
        fill_value: a float represents the value to be filled outside the boundaries
            when `fill_mode` is "constant".
    """
    bs = _get_batch_size(image)
    pixels = tf.cast(tf.random.uniform((bs,), -max_pixels, max_pixels)[0], tf.int64)
    return apply_translate_x(image, pixels, fill_mode, fill_value)


@tf.function
def apply_translate_x(image, pixels, fill_mode="nearest", fill_value=0.0):
    """
    Equivalent of PIL Translate in X dimension.

    Args:
        images: the image to augment, a 3D or 4D tensor of type uint8 or float32.
        pixels: int: pixel displacement on the y axis.
        fill_mode: Points outside the boundaries of the input are filled according to
            the given mode (one of `{'constant', 'reflect', 'wrap', 'nearest'}`)
        fill_value: a float represents the value to be filled outside the boundaries
            when `fill_mode` is "constant".
    """
    return contrib_image.translate(
        image, [-pixels, 0], fill_mode=fill_mode, fill_value=fill_value
    )


def random_translate_y(image, max_pixels, fill_mode="nearest", fill_value=0.0):
    """
    Equivalent of PIL Translate in Y dimension.

    .. image:: augmentation/random_translate_y.png

    Args:
        images: the image to augment, a 3D or 4D tensor of type uint8 or float32.
        max_pixels: int: max pixel displacement on the y axis.
        fill_mode: Points outside the boundaries of the input are filled according to
            the given mode (one of `{'constant', 'reflect', 'wrap', 'nearest'}`)
        fill_value: a float represents the value to be filled outside the boundaries
            when `fill_mode` is "constant".
    """
    bs = _get_batch_size(image)
    pixels = tf.cast(tf.random.uniform((bs,), -max_pixels, max_pixels)[0], tf.int64)
    return apply_translate_y(image, pixels, fill_mode, fill_value)


@tf.function
def apply_translate_y(image, pixels, fill_mode="nearest", fill_value=0.0):
    """
    Equivalent of PIL Translate in Y dimension.

    Args:
        images: the image to augment, a 3D or 4D tensor of type uint8 or float32.
        pixels: int: pixel displacement on the y axis.
        fill_mode: Points outside the boundaries of the input are filled according to
            the given mode (one of `{'constant', 'reflect', 'wrap', 'nearest'}`)
        fill_value: a float represents the value to be filled outside the boundaries
            when `fill_mode` is "constant".
    """
    return contrib_image.translate(
        image, [0, -pixels], fill_mode=fill_mode, fill_value=fill_value
    )


def random_shear_x(images, max_factor, fill_mode="nearest", fill_value=0.0):
    """
    Equivalent of PIL Shearing in X dimension.

    .. image:: augmentation/random_shear_x.png

    Args:
        images: the image to augment, a 3D or 4D tensor of type uint8 or float32.
        max_factor: float: when 0 no shear is applied, when 1 each line will be shifted
            by one pixel with respect to the previous line
        fill_mode: Points outside the boundaries of the input are filled according to
            the given mode (one of `{'constant', 'reflect', 'wrap', 'nearest'}`)
        fill_value: a float represents the value to be filled outside the boundaries
            when `fill_mode` is "constant".
    """
    # Shear parallel to x axis is a projective transform
    # with a matrix form of:
    # [1  level
    #  0  1].
    bs = _get_batch_size(images)
    factor = tf.random.uniform((bs,), -max_factor, max_factor)[0]
    return apply_shear_x(images, factor, fill_mode, fill_value)


@tf.function
def apply_shear_x(images, factor, fill_mode="nearest", fill_value=0.0):
    """
    Equivalent of PIL Shearing in X dimension.

    Args:
        images: the image to augment, a 3D or 4D tensor of type uint8 or float32.
        factor: float: when 0 no shear is applied, when 1 each line will be shifted
            by one pixel with respect to the previous line
        fill_mode: Points outside the boundaries of the input are filled according to
            the given mode (one of `{'constant', 'reflect', 'wrap', 'nearest'}`)
        fill_value: a float represents the value to be filled outside the boundaries
            when `fill_mode` is "constant".
    """
    # Shear parallel to x axis is a projective transform
    # with a matrix form of:
    # [1  level
    #  0  1].
    ones = tf.ones_like(factor)
    zeroes = tf.zeros_like(factor)
    return contrib_image.transform(
        images,
        [ones, factor, zeroes, zeroes, ones, zeroes, zeroes, zeroes],
        fill_mode=fill_mode,
        fill_value=fill_value,
    )


def random_shear_y(images, max_factor, fill_mode="nearest", fill_value=0.0):
    """
    Equivalent of PIL Shearing in Y dimension.

    .. image:: augmentation/random_shear_y.png

    Args:
        images: the image to augment, a 3D or 4D tensor of type uint8 or float32.
        max_factor: float: when 0 no shear is applied, when 1 each column will be
            shifted by one pixel with respect to the previous column
        fill_mode: Points outside the boundaries of the input are filled according to
            the given mode (one of `{'constant', 'reflect', 'wrap', 'nearest'}`).
        fill_value: a float represents the value to be filled outside the boundaries
            when `fill_mode` is "constant".
    """
    # Shear parallel to y axis is a projective transform
    # with a matrix form of:
    # [1  0
    #  level  1].
    bs = _get_batch_size(images)
    factor = tf.random.uniform((bs,), -max_factor, max_factor)[0]
    return apply_shear_y(images, factor, fill_mode, fill_value)


@tf.function
def apply_shear_y(images, factor, fill_mode="nearest", fill_value=0.0):
    """
    Equivalent of PIL Shearing in Y dimension.

    Args:
        images: the image to augment, a 3D or 4D tensor of type uint8 or float32.
        factor: float: when 0 no shear is applied, when 1 each column will be
            shifted by one pixel with respect to the previous column
        fill_mode: Points outside the boundaries of the input are filled according to
            the given mode (one of `{'constant', 'reflect', 'wrap', 'nearest'}`).
        fill_value: a float represents the value to be filled outside the boundaries
            when `fill_mode` is "constant".
    """
    # Shear parallel to y axis is a projective transform
    # with a matrix form of:
    # [1  0
    #  level  1].
    ones = tf.ones_like(factor)
    zeroes = tf.zeros_like(factor)
    return contrib_image.transform(
        images,
        [ones, zeroes, zeroes, factor, ones, zeroes, zeroes, zeroes],
        fill_mode=fill_mode,
        fill_value=fill_value,
    )


def random_autocontrast(image):
    """
    Implements Autocontrast function from PIL using TF ops.

    .. image:: augmentation/random_autocontrast.png

    Args:
      image: A 3D uint8 tensor.

    Returns:
      The image after it has had autocontrast applied to it and will be of type
      uint8.
    """
    bs = _get_batch_size(image)
    factor = tf.random.uniform((bs,), 0, 1)[0]
    return tf.where(factor > 0.5, apply_autocontrast(image), image)


@tf.function
def apply_autocontrast(image):
    """
    Implements Autocontrast function from PIL using TF ops.

    Args:
      image: A 3D uint8 tensor.

    Returns:
      The image after it has had autocontrast applied to it and will be of type
      uint8.
    """

    def scale_channel(image):
        """Scale the 2D image using the autocontrast rule."""
        # A possibly cheaper version can be done using cumsum/unique_with_counts
        # over the histogram values, rather than iterating over the entire image.
        # to compute mins and maxes.
        orig_dtype = image.dtype
        lo = tf.cast(tf.reduce_min(image), tf.float32)
        hi = tf.cast(tf.reduce_max(image), tf.float32)

        # Scale the image, making the lowest value 0 and the highest value 255.
        def scale_values(im):
            if orig_dtype.is_floating:
                scale = 1.0 / (hi - lo)
            else:
                scale = 255.0 / (hi - lo)
            offset = -lo * scale
            im = tf.cast(im, tf.float32) * scale + offset
            if orig_dtype.is_floating:
                im = tf.clip_by_value(im, 0.0, 1.0)
            else:
                im = tf.clip_by_value(im, 0.0, 255.0)
            return tf.cast(im, orig_dtype)

        result = tf.cond(hi > lo, lambda: scale_values(image), lambda: image)
        return result

    # Assumes RGB for now.  Scales each channel independently
    # and then stacks the result.
    s1 = scale_channel(image[:, :, 0])
    s2 = scale_channel(image[:, :, 1])
    s3 = scale_channel(image[:, :, 2])
    image = tf.stack([s1, s2, s3], 2)
    return image


def random_sharpness(image, max_factor):
    """
    Implements Sharpness function from PIL using TF ops.

    .. image:: augmentation/random_sharpness.png

    Args:
        image: the image to augment, a 3D or 4D tensor of type uint8 or float32.
        max_factor: when factor=0, return the original image, when factor=1 return up to
            the blurred image.

    Returns:
        a blend between the original image and a smoothed version (gaussian blur).

    """
    bs = _get_batch_size(image)
    factor = tf.random.uniform((bs,), 0, max_factor)[0]
    return apply_sharpness(image, factor)


@tf.function
def apply_sharpness(image, factor):
    """
    Implements Sharpness function from PIL using TF ops.

    Args:
        image: the image to augment, a 3D or 4D tensor of type uint8 or float32.
        factor: when factor=0, return the original image, when factor=1 return up to
            the blurred image.

    Returns:
        a blend between the original image and a smoothed version (gaussian blur).

    """
    orig_image = image
    orig_dtype = image.dtype
    is_batched = len(image.shape) == 3
    image = tf.cast(image, tf.float32)
    # Make image 4D for conv operation.
    if is_batched:
        image = tf.expand_dims(image, 0)
    # SMOOTH PIL Kernel.
    kernel = (
        tf.constant(
            [[1, 1, 1], [1, 5, 1], [1, 1, 1]], dtype=tf.float32, shape=[3, 3, 1, 1]
        )
        / 13.0
    )
    # Tile across channel dimension.
    kernel = tf.tile(kernel, [1, 1, 3, 1])
    strides = [1, 1, 1, 1]
    with tf.device("/cpu:0"):
        # Some augmentation that uses depth-wise conv will cause crashing when
        # training on GPU. See (b/156242594) for details.
        degenerate = tf.nn.depthwise_conv2d(
            image, kernel, strides, padding="VALID", dilations=[1, 1]
        )
    clip_high = 1.0 if orig_dtype.is_floating else 255.0
    degenerate = tf.clip_by_value(degenerate, 0.0, clip_high)
    degenerate = tf.squeeze(tf.cast(degenerate, orig_dtype), [0])

    # For the borders of the resulting image, fill in the values of the
    # original image.
    mask = tf.ones_like(degenerate)
    padded_mask = tf.pad(mask, [[1, 1], [1, 1], [0, 0]])
    padded_degenerate = tf.pad(degenerate, [[1, 1], [1, 1], [0, 0]])
    result = tf.where(tf.equal(padded_mask, 1), padded_degenerate, orig_image)

    # Blend the final result.
    return _blend(orig_image, result, factor)


def random_equalize(image):
    """
    Implements Equalize function from PIL using TF ops.
    Doesn't work with images in float32, nor with batched images.

    .. image:: augmentation/random_equalize.png

    Args:
        image: the image to augment, a 3D tensor of type uint8.

    Returns:
        the equalized image
    """
    bs = _get_batch_size(image)
    factor = tf.random.uniform((bs,), 0, 1)[0]
    return tf.where(factor > 0.5, apply_equalize(image), image)


@tf.function
def apply_equalize(image):
    """
    Implements Equalize function from PIL using TF ops.
    Doesn't work with images in float32, nor with batched images.

    Args:
        image: the image to augment, a 3D tensor of type uint8.

    Returns:
        the equalized image
    """
    orig_dtype = image.dtype
    image = tf.image.convert_image_dtype(image, tf.uint8)

    def scale_channel(im, c):
        """Scale the data in the channel to implement equalize."""
        im = tf.cast(im[:, :, c], tf.int32)
        # Compute the histogram of the image channel.
        histo = tf.histogram_fixed_width(im, [0, 255], nbins=256)

        # For the purposes of computing the step, filter out the nonzeros.
        nonzero = tf.where(tf.not_equal(histo, 0))
        nonzero_histo = tf.reshape(tf.gather(histo, nonzero), [-1])
        step = (tf.reduce_sum(nonzero_histo) - nonzero_histo[-1]) // 255

        def build_lut(histo, step):
            # Compute the cumulative sum, shifting by step // 2
            # and then normalization by step.
            lut = (tf.cumsum(histo) + (step // 2)) // step
            # Shift lut, prepending with 0.
            lut = tf.concat([[0], lut[:-1]], 0)
            # Clip the counts to be in range.  This is done
            # in the C code for image.point.
            return tf.clip_by_value(lut, 0, 255)

        # If step is zero, return the original image.  Otherwise, build
        # lut from the full histogram and step and then index from it.
        result = tf.cond(
            tf.equal(step, 0), lambda: im, lambda: tf.gather(build_lut(histo, step), im)
        )

        return tf.cast(result, tf.uint8)

    # Assumes RGB for now.  Scales each channel independently
    # and then stacks the result.
    s1 = scale_channel(image, 0)
    s2 = scale_channel(image, 1)
    s3 = scale_channel(image, 2)
    image = tf.stack([s1, s2, s3], 2)
    return tf.image.convert_image_dtype(image, orig_dtype)


def random_invert(image):
    """
    Inverts the image pixels.

    .. image:: augmentation/random_invert.png
    """
    bs = _get_batch_size(image)
    factor = tf.random.uniform((bs,), 0, 1)[0]
    return tf.where(factor > 0.5, apply_invert(image), image)


@tf.function
def apply_invert(images):
    """Inverts the image pixels."""
    max_val = 1.0 if images.dtype.is_floating else 255
    return max_val - images


def _get_batch_size(image):
    shape = image.shape
    if len(shape) == 3:
        return 1
    else:
        return tf.cast(shape[0], tf.int64)


if __name__ == "__main__":
    from data.loader import get_tfds_by_name
    from dlt.model_factory.utils import ClassParam
    from dlt.data.pipeline import get_sequence_x
    import matplotlib.pyplot as plt

    import cv2

    cap = cv2.VideoCapture(
        "https://www.thehistoryhub.com/wp-content/uploads/2014/08/Burgos-Cathedral-Images.jpg"
    )
    if cap.isOpened():
        ret, img = cap.read()
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    # img = cv2.imread("calibration.jpg")
    aug_list = [
        ClassParam(randaugment, nb_layers=2, magnitude=5),
        ClassParam(
            randaugment,
            nb_layers=2,
            magnitude=5,
            remove_augmentations=[random_invert],
            extra_augmentations={
                random_hue: lambda level, img_shape: (0.25 * level / 10,),
                random_resizedcrop: lambda level, img_shape: (
                    (1-0.5*(level/10), 1.0),
                    (1.0+(level/10.), 1./(1.0+(level/10.))),
                )
            },
            extra_kwargs={random_shear_x: {"fill_mode": "constant", "fill_value": 0}},
        ),
        ClassParam(randaugment, nb_layers=2, magnitude=10),
        ClassParam(
            random_resizedcrop,
            scale=(0.5, 1.0),
            ratio=(3 / 4, 4 / 3),
            interpolation="bilinear",
        ),
        ClassParam(random_rotate, max_rotation=30),
        ClassParam(random_cutout, pad_size=32),
        ClassParam(random_translate_x, max_pixels=32),
        ClassParam(random_translate_y, max_pixels=32),
        ClassParam(random_shear_x, max_factor=0.15),
        ClassParam(random_shear_y, max_factor=0.15),
        ClassParam(random_brightness, max_delta=0.5),
        ClassParam(random_contrast, lower=0.8, upper=1.2),
        ClassParam(random_saturation, lower=0.5, upper=1.5),
        ClassParam(random_hue, max_delta=0.25),
        ClassParam(random_color, max_factor=1.0),
        ClassParam(random_sharpness, max_factor=1.0),
        ClassParam(random_solarize, threshold=128),
        ClassParam(random_solarize_add, addition=64, threshold=128),
        ClassParam(random_autocontrast),
        ClassParam(random_equalize),
        ClassParam(random_invert),
        ClassParam(random_jpeg_quality, min_jpeg_quality=25, max_jpeg_quality=100),
        ClassParam(random_posterize, max_bits=8),
        ClassParam(random_flip_left_right),
        ClassParam(random_flip_up_down),
    ]
    img = cv2.resize(img, dsize=None, fx=0.25, fy=0.25)
    tf_img = tf.convert_to_tensor(img, dtype=tf.uint8)
    image_batch = tf.repeat(
        tf.expand_dims(tf.convert_to_tensor(img, dtype=tf.uint8), axis=0),
        2 * len(aug_list),
        axis=0,
    )
    # plt.tight_layout()
    nb_tries = 10
    scale = 3
    figsize = (5 * scale - 1, (nb_tries//5) * scale + 1)
    for aug in aug_list:
        plt.clf()
        fig, axes = plt.subplots(
            ncols=5,
            nrows=nb_tries // 5,
            figsize=figsize,
            squeeze=False,
            constrained_layout=True,
        )
        fig.suptitle(f"{str(aug)}")
        for t in range(nb_tries):
            out_img = aug(tf_img)
            ax = axes[t//5][t%5]
            ax.set_xticks([])
            ax.set_yticks([])
            ax.axis("off")
            ax.imshow(out_img)
        # plt.subplots_adjust(
        #     wspace=0.0, hspace=0.0, top=0.95, bottom=0.05, left=0.17, right=0.845
        # )
        plt.subplots_adjust(left=0, bottom=0, right=1, top=1, wspace=0, hspace=0)
        # plt.margins(0, tight=True)
        # plt.tight_layout()
        # plt.savefig(f"doc/build/html/augmentation/{aug.fct.__name__}.png")
        plt.waitforbuttonpress(100)
    plt.clf()

    ds_train, ds_test, metadata = get_tfds_by_name("cifar10")
    res = (
        ds_train.take(10)
        .map(
            get_sequence_x(
                [
                    # ClassParam(random_rotate, max_rotation=5),
                    # ClassParam(random_translate_x, max_pixels=2),
                    # ClassParam(random_translate_y, max_pixels=2),
                    # ClassParam(random_shear_x, max_factor=0.1),
                    # ClassParam(random_shear_y, max_factor=0.1),
                    # ClassParam(random_brightness, max_delta=0.5),
                    # ClassParam(random_contrast, lower=0.8, upper=1.2),
                    # ClassParam(random_saturation, lower=0.8, upper=1.2),
                    # ClassParam(random_hue, max_delta=0.25),
                    # ClassParam(random_color, max_factor=1.0),
                    # ClassParam(random_sharpness, max_factor=1.0),
                    # ClassParam(random_solarize_add, addition=16, threshold=128),
                    # ClassParam(random_solarize, threshold=128),
                    # ClassParam(random_autocontrast),
                    # ClassParam(random_equalize),
                    # ClassParam(random_invert),
                    # ClassParam(
                    #     random_jpeg_quality, min_jpeg_quality=25, max_jpeg_quality=100
                    # ),
                    # ClassParam(random_posterize, max_bits=8),
                    # ClassParam(random_flip_left_right),
                    # ClassParam(random_flip_up_down),
                    # ClassParam(randaugment, nb_layers=2, magnitude=5),
                    # ClassParam(
                    #     random_resizedcrop,
                    #     scale=(0.5, 1.0),
                    #     ratio=(3 / 4, 4 / 3),
                    #     interpolation="bilinear",
                    # ),
                    # ClassParam(random_cutout, pad_size=4),
                    ClassParam(
                        randaugment,
                        nb_layers=2,
                        magnitude=5,
                        remove_augmentations=[random_invert, random_solarize],
                        extra_augmentations={
                            random_hue: lambda level, img_shape: (0.25 * level / 10,),
                            random_resizedcrop: lambda level, img_shape: (
                                (1 - 0.5 * (level / 10), 1.0),
                                (1.0 + (level / 10.), 1. / (1.0 + (level / 10.))),
                            )
                        },
                    ),
                ]
            )
        )
        .batch(10)
    )

    it = res.as_numpy_iterator()
    for i in range(1):
        imgs, labels = it.next()
        for i in range(imgs.shape[0]):
            plt.imshow(imgs[i, :, :, :] / 255)
            plt.waitforbuttonpress()
