import tensorflow as tf
import numpy as np
import tensorflow_datasets as tfds
from .utils import get_metadata_from_ds_info
import deel.datasets as dds
import os


def get_tfds_by_name(name, **kwargs):
    """
    Generic loader for tfds datasets.

    Args:
        name: string: the name of the dataset, given to `tfds.load`
        kwargs: extra kwargs given to `tfds.load`

    Returns:
        Dataset, Dataset, dict: the train set and the validation set both as tensorflow
        datasets and a dict with dataset metadata (including: input_shape,
        nb_classes, nb_samples_train, nb_samples_test, class_names). See
        :func:`data.utils.get_metadata_from_ds_info` for more informations.

    """
    (ds_train, ds_test), info = tfds.load(
        name,
        split=["train", "test"],
        shuffle_files=True,
        as_supervised=True,
        with_info=True,
        **kwargs,
    )
    metadata = get_metadata_from_ds_info(info)
    return ds_train, ds_test, metadata


def get_mnist():
    """
    load mnist.

    Returns:
        Dataset, Dataset, dict: the train set and the validation set both as tensorflow
        datasets and a dict with dataset metadata (including: input_shape,
        nb_classes, nb_samples_train, nb_samples_test, class_names). See
        :func:`data.utils.get_metadata_from_ds_info` for more informations.

    """
    return get_tfds_by_name("mnist")


def get_cifar10():
    """
    load cifar10.

    Returns:
        Dataset, Dataset, dict: the train set and the validation set both as tensorflow
        datasets and a dict with dataset metadata (including: input_shape,
        nb_classes, nb_samples_train, nb_samples_test, class_names). See
        :func:`data.utils.get_metadata_from_ds_info` for more informations.

    """
    return get_tfds_by_name("cifar10")


def get_cifar100():
    """
    load cifar100.

    Returns:
        Dataset, Dataset, dict: the train set and the validation set both as tensorflow
        datasets and a dict with dataset metadata (including: input_shape,
        nb_classes, nb_samples_train, nb_samples_test, class_names). See
        :func:`data.utils.get_metadata_from_ds_info` for more informations.

    """
    return get_tfds_by_name("cifar100")


def get_eurosat(nb_test=5400):
    """
    Load the eurosat dataset, with 64x64 rgb images.

    Args:
        nb_test: number of images to keep for the validation split.

    Returns:
        Dataset, Dataset, dict: the train set and the validation set both as tensorflow
        datasets and a dict with dataset metadata (including: input_shape,
        nb_classes, nb_samples_train, nb_samples_test, class_names). See
        :func:`data.utils.get_metadata_from_ds_info` for more informations.

    """
    ds_train, info = tfds.load(
        "eurosat/rgb",
        split="train",
        shuffle_files=True,
        as_supervised=True,
        with_info=True,
    )
    metadata = {
        "input_shape": info.features["image"].shape,
        "nb_classes": info.features["label"].num_classes,
        "nb_samples_train": info.splits["train"].num_examples - nb_test,
        "nb_samples_test": nb_test,
    }
    return (
        ds_train.take(metadata["nb_samples_train"]),
        ds_train.skip(metadata["nb_samples_train"]),
        metadata,
    )


def get_celeb_a_multilabel():
    """
    Get Celeb A images as a multi label classification dataset.

    Returns:
        Dataset, Dataset, dict: the train set and the validation set both as tensorflow
        datasets and a dict with dataset metadata (including: input_shape,
        nb_classes, nb_samples_train, nb_samples_test, class_names). See
        :func:`data.utils.get_metadata_from_ds_info` for more informations.
    """
    (ds_train, ds_test), info = tfds.load(
        "celeb_a",
        split=["train", "test"],
        shuffle_files=True,
        with_info=True,
    )
    metadata = {
        "input_shape": info.features["image"].shape,
        "nb_classes": len(info.features["attributes"]),
        "nb_samples_train": info.splits["train"].num_examples,
        "nb_samples_test": info.splits["test"].num_examples,
        "class_names": list(info.features["attributes"].keys()),
    }
    preprocess = lambda batch: (
        batch["image"],
        tf.cast(tf.stack(list(batch["attributes"].values()), axis=-1), tf.float32),
    )
    return ds_train.map(preprocess), ds_test.map(preprocess), metadata


def get_welding(image_size, batch_size=1, percent_val=0.2):
    """
    Get the welding dataset. As the dataset is heavily unbalanced and as no train/val
    split is done, the following procedure is performed:

    1. The OK and NOK images are loaded separately, with shuffling seed fixed
    2. Train/Val split is performed, to ensure that both classes have the right
      proportions in both train and val.
    3. train_ok and train_nok are merge, similarly val_ok and vol_nok are merged.
    4. train dataset is rebalanced by repeating the nok element. By doing so we can
    ensure that each batch contains 50% of ok and 50% of nok. Each ok will be seen
    once per epoch while nok will be seen multiple times.

    Args:
        image_size: (int, int): the output image size.
        batch_size: int: batch size used when loading the images. The output datasets
            are still unbatched.
        percent_val: float between 0 and 1: the percentage of images to keep in the
            validation split.

    Returns:
        Dataset, Dataset, dict: the train set and the validation set both as tensorflow
        datasets and a dict with dataset metadata (including: input_shape,
        nb_classes, nb_samples_train, nb_samples_test, class_names). See
        :func:`data.utils.get_metadata_from_ds_info` for more informations.
    """
    path = dds.load("welding", version="1.0.1")
    ok_path = os.path.join(path, "OK")
    nok_path = os.path.join(path, "NOK")
    # compute datasets length
    nok_len = 828
    nok_val_len = int(nok_len * percent_val)
    nok_train_len = nok_len - nok_val_len
    ok_len = 101335
    ok_val_len = int(ok_len * percent_val)
    ok_train_len = ok_len - ok_val_len
    # parameters for image loading
    img_dataset_kwargs = dict(
        labels=None,
        batch_size=batch_size,
        image_size=image_size,
        shuffle=True,
        interpolation="lanczos5",
        crop_to_aspect_ratio=True,
        seed=42,
        validation_split=percent_val,
        follow_links=True,
    )
    # retrieve separately ok and nok
    nok_ds_train = tf.keras.utils.image_dataset_from_directory(
        nok_path,
        subset="training",
        **img_dataset_kwargs,
    )
    nok_ds_val = tf.keras.utils.image_dataset_from_directory(
        nok_path,
        subset="validation",
        **img_dataset_kwargs,
    )
    ok_ds_train = tf.keras.utils.image_dataset_from_directory(
        ok_path,
        subset="training",
        **img_dataset_kwargs,
    )
    ok_ds_val = tf.keras.utils.image_dataset_from_directory(
        ok_path,
        subset="validation",
        **img_dataset_kwargs,
    )
    # # add labels
    ok_ds_train = ok_ds_train.map(lambda x: (x, tf.zeros(batch_size))).unbatch()
    ok_ds_val = ok_ds_val.map(lambda x: (x, tf.zeros(batch_size))).unbatch()
    nok_ds_train = nok_ds_train.map(lambda x: (x, tf.ones(batch_size))).unbatch()
    nok_ds_val = nok_ds_val.map(lambda x: (x, tf.ones(batch_size))).unbatch()
    # join dataset
    nok_ds_train = nok_ds_train.repeat(ok_train_len // nok_train_len)
    ds_train = tf.data.Dataset.choose_from_datasets(
        [ok_ds_train, nok_ds_train],
        tf.data.Dataset.range(2).repeat(2 * ok_train_len),
        stop_on_empty_dataset=True,
    )
    ds_val = tf.data.Dataset.concatenate(ok_ds_val, nok_ds_val)
    metadata = {
        "input_shape": (image_size[0], image_size[1], 3),
        "nb_classes": 2,
        "nb_samples_train": 2 * ok_train_len,
        "nb_samples_test": ok_val_len + nok_val_len,
        "class_names": ["OK", "NOK"],
    }
    return ds_train.cache(), ds_val.cache(), metadata


def get_imagenet(path, image_size=(256, 256), cache_path=None):
    """
    create tfrecords from the raw dataset folder. The raw data must be presented as
    following:

    1. the dataset must be downloaded from the `kaggle challenge`_
    2. the validation labels must be downloaded from the `tensorflow research
      models`_ repo.
    3. the validation labels must be placed in the `ILSVRC/Data/CLS-LOC` folder.

    This function takes the raw images, reshape it using central crop and resize,
    convert it to tensors and return the dataset. The loaded tensors can be cached on
    disk by setting the cache_path.

    Args:
        path (str): the path pointing to the raw data. This must point to the
            `ILSVRC/Data/CLS-LOC` folder. The train/val split are made by appending
            `train` and `val` to this path.
        image_size (tuple, optional): shape of the resized images in 2D. Defaults to
            (256, 256).
        cache_path (str): path where the output tensors will be loaded. This path can
            be passed as parameter to the `get_imagenet_cached` function. When set to
            None, the cache is not saved, and the dataset is returned.

    Returns:
        Dataset, Dataset, dict: the train set and the validation set both as tensorflow
        datasets and a dict with dataset metadata (including: input_shape,
        nb_classes, nb_samples_train, nb_samples_test, class_names). See
        :func:`data.utils.get_metadata_from_ds_info` for more informations.

    .. _kaggle challenge:
        https://www.kaggle.com/c/imagenet-object-localization-challenge

    .. _tensorflow research:
        https://raw.githubusercontent.com/tensorflow/models/master/research/slim/datasets/imagenet_2012_validation_synset_labels.txt
    """
    import sys

    # prepare paths and load utils files
    path_train = os.path.join(path, "train")
    path_test = os.path.join(path, "val")
    # build structure for val dataset
    is_unformatted = len([name for name in os.listdir(path_test)]) > 5000
    if is_unformatted:
        path_test_labels = os.path.join(
            path, "imagenet_2012_validation_synset_labels.txt"
        )
        val_labels = np.loadtxt(path_test_labels)
        # Read in the 50000 synsets associated with the validation data set.
        labels = [l.strip() for l in open(path_test_labels).readlines()]
        unique_labels = set(labels)

        # Make all sub-directories in the validation data dir.
        for label in unique_labels:
            labeled_data_dir = os.path.join(path_test, label)
            os.makedirs(labeled_data_dir)

        # Move all of the image to the appropriate sub-directory.
        for i in range(len(labels)):
            basename = "ILSVRC2012_val_000%.5d.JPEG" % (i + 1)
            original_filename = os.path.join(path_test, basename)
            if not os.path.exists(original_filename):
                print("Failed to find: ", original_filename)
                sys.exit(-1)
            new_filename = os.path.join(path_test, labels[i], basename)
            os.rename(original_filename, new_filename)
    # now that the directory structure is correct we can load the data
    ds_train = tf.keras.utils.image_dataset_from_directory(
        path_train,
        labels="inferred",
        label_mode="int",
        batch_size=256,
        image_size=image_size,
        shuffle=True,
        interpolation="bilinear",
        crop_to_aspect_ratio=True,
    )
    ds_test = tf.keras.utils.image_dataset_from_directory(
        path_test,
        labels="inferred",
        label_mode="int",
        batch_size=256,
        image_size=image_size,
        shuffle=False,
        interpolation="bilinear",
        crop_to_aspect_ratio=True,
    )
    metadata = {
        "input_shape": (image_size[0], image_size[1], 3),
        "nb_classes": 1000,
        "nb_samples_train": 1281167,
        "nb_samples_test": 50000,
    }
    # now prepare data (casting to appropriate type)
    ds_train = ds_train.map(
        lambda x, y: (tf.cast(x, tf.uint8), tf.cast(y, tf.int32)),
        num_parallel_calls=tf.data.AUTOTUNE,
    )
    ds_test = ds_test.map(
        lambda x, y: (tf.cast(x, tf.uint8), tf.cast(y, tf.int32)),
        num_parallel_calls=tf.data.AUTOTUNE,
    )
    ds_train, ds_test = ds_train.unbatch(), ds_test.unbatch()
    # save it to disk
    if cache_path is not None:
        tf.data.experimental.save(ds_test, os.path.join(cache_path, "val"))
        tf.data.experimental.save(ds_train, os.path.join(cache_path, "train"))
    return ds_train, ds_test, metadata


def get_imagenet_cached(path):
    """
    load cached tensors as tf dataset. Those cached tensors can be obtained by
    calling :func:`get_imagenet` with `cache_path!=None`.

    Args:
        path (str): a path leading to the tensors. Must point to a directory
            containing a `train` and a `val` directory.

    Returns:
        Dataset, Dataset, dict: the train set and the validation set both as tensorflow
        datasets and a dict with dataset metadata (including: input_shape,
        nb_classes, nb_samples_train, nb_samples_test, class_names). See
        :func:`data.utils.get_metadata_from_ds_info` for more informations.
    """
    train_df = tf.data.experimental.load(os.path.join(path, "train"))
    val_df = tf.data.experimental.load(os.path.join(path, "val"))
    metadata = {
        "input_shape": train_df.element_spec[0].shape.as_list(),
        "nb_classes": 1000,
        "nb_samples_train": 1281167,
        "nb_samples_test": 50000,
    }
    return train_df, val_df, metadata


def get_imagenet_resized(size):
    """
    Get a downsized version of imagenet. See the `tensorflow datasets description`_
    for more infos.

    Args:
        size: int, the size of the images. Size must be one of {8, 16, 32, 64}

    Warning:
        The link in tfds is broken, it must be corrected by editing the source code
        of tfds. See `this issue`_ to see what need to be done.

    Returns:
        Dataset, Dataset, dict: the train set and the validation set both as tensorflow
        datasets and a dict with dataset metadata (including: input_shape,
        nb_classes, nb_samples_train, nb_samples_test, class_names). See
        :func:`data.utils.get_metadata_from_ds_info` for more informations.

    .. _tensorflow datasets description:
        https://www.tensorflow.org/datasets/catalog/imagenet_resized

    .. _this issue:
        https://github.com/tensorflow/datasets/issues/3713

    """
    if not (size in {8, 16, 32, 64}):
        raise RuntimeError("size must be in {8, 16, 32, 64}")
    (ds_train, ds_test), info = tfds.load(
        f"imagenet_resized/{size}x{size}",
        split=["train", "validation"],
        shuffle_files=True,
        as_supervised=True,
        with_info=True,
    )
    metadata = get_metadata_from_ds_info(info)
    return ds_train, ds_test, metadata
